from workers import celery
from flask import current_app
from models import db, User, Quiz, Score, Chapter, Subject
from datetime import datetime, timedelta
import csv
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from jinja2 import Environment, FileSystemLoader
from io import StringIO
import os
from sqlalchemy import func
from celery.schedules import crontab
from weasyprint import HTML

@celery.task
def send_daily_reminder():
    with current_app.app_context():
        ten_hours_ago = datetime.now() - timedelta(hours=10)
        
        inactive_users = User.query.filter(
            User.is_admin == False,
            ~User.id.in_(
                Score.query.filter(
                    Score.time_stamp_of_attempt > ten_hours_ago
                ).with_entities(Score.user_id)
            )
        ).all()
        
        one_day_ago = datetime.now() - timedelta(days=1)
        new_quizzes = Quiz.query.filter(
            Quiz.created_at > one_day_ago
        ).all()
        
        if not new_quizzes and not inactive_users:
            return "No reminders needed"
        
        for user in inactive_users:
            subject = "We miss you at Quiz App!"
            html_content = f"""
            <html>
            <body>
                <h2>Hello {user.fullname},</h2>
                <p>We noticed you haven't taken any quizzes recently.</p>
                <p>Why not log in and test your knowledge today?</p>
                <p>Best regards,<br>The Quiz App Team</p>
            </body>
            </html>
            """
            send_email(user.email, subject, html_content)
        
        if new_quizzes:
            all_users = User.query.filter(User.is_admin == False).all()
            quiz_list = "<ul>" + "".join([f"<li>{quiz.remarks} (Chapter: {quiz.chapter.name if quiz.chapter else 'Unknown'})</li>" 
                                for quiz in new_quizzes]) + "</ul>"
            
            for user in all_users:
                subject = "New Quizzes Available!"
                html_content = f"""
                <html>
                <body>
                    <h2>Hello {user.fullname},</h2>
                    <p>We have some new quizzes available for you to try:</p>
                    {quiz_list}
                    <p>Log in now to test your knowledge!</p>
                    <p>Best regards,<br>The Quiz App Team</p>
                </body>
                </html>
                """
                send_email(user.email, subject, html_content)
        
        return f"Sent reminders to {len(inactive_users)} inactive users and notified {len(all_users) if new_quizzes else 0} users about new quizzes"

@celery.task
def send_monthly_report():
    """Generate and send monthly activity reports to all users."""
    with current_app.app_context():
        users = User.query.filter_by(is_admin=False).all()
        
        for user in users:
            user_scores = Score.query.filter(Score.user_id == user.id).all()
            
            if not user_scores:

                subject = f"Your Quiz Activity Report"
                html_content = f"""
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333; }}
                        .container {{ max-width: 600px; margin: 0 auto; }}
                        .header {{ background-color: #4CAF50; color: white; padding: 10px; text-align: center; }}
                        .content {{ padding: 20px; background-color: #f9f9f9; }}
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h1>Monthly Activity Report</h1>
                            <h2>Total</h2>
                        </div>
                        <div class="content">
                            <p>Hello {user.fullname},</p>
                            <p>We noticed you didn't take any quizzes yet. Challenge yourself!</p>
                            <p>Log in to the Quiz App to explore available quizzes and test your knowledge.</p>
                        </div>
                    </div>
                </body>
                </html>
                """
                send_email(user.email, subject, html_content)
                continue
            
            total_quizzes = len(user_scores)
            avg_score = sum(score.percentage for score in user_scores) / total_quizzes if total_quizzes > 0 else 0
            
            subject_performance = {}
            for score in user_scores:
                quiz = Quiz.query.get(score.quiz_id)
                if not quiz or not quiz.chapter:
                    continue
                    
                subject = Subject.query.get(quiz.chapter.subject_id)
                if not subject:
                    continue
                    
                if subject.name not in subject_performance:
                    subject_performance[subject.name] = {
                        'attempts': 0,
                        'total_score': 0
                    }
                
                subject_performance[subject.name]['attempts'] += 1
                subject_performance[subject.name]['total_score'] += score.percentage
            
            for subject in subject_performance:
                subject_performance[subject]['avg_score'] = (
                    subject_performance[subject]['total_score'] / 
                    subject_performance[subject]['attempts']
                )
            
            
            all_user_scores = db.session.query(
                Score.user_id,
                func.avg(Score.percentage).label('avg_score')
            ).group_by(Score.user_id).all()
            
            all_user_scores.sort(key=lambda x: x[1], reverse=True)
            
            
            user_rank = None
            for i, (user_id, _) in enumerate(all_user_scores):
                if user_id == user.id:
                    user_rank = i + 1
                    break
        
            subject_rows = ""
            for subject_name, data in subject_performance.items():
                subject_rows += f"""
                <tr>
                    <td>{subject_name}</td>
                    <td>{data['attempts']}</td>
                    <td>{data['avg_score']:.1f}%</td>
                </tr>
                """
            
            html_content = f"""
            <html>
            <head>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333; }}
                    .container {{ max-width: 600px; margin: 0 auto; }}
                    .header {{ background-color: #4CAF50; color: white; padding: 10px; text-align: center; }}
                    .stats {{ margin: 20px 0; }}
                    .stat-box {{ background-color: #f2f2f2; padding: 15px; margin: 10px 0; border-radius: 5px; }}
                    table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
                    th, td {{ padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }}
                    th {{ background-color: #f2f2f2; }}
                    .footer {{ margin-top: 30px; font-size: 0.8em; color: #666; text-align: center; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>Monthly Activity Report</h1>
                        <h2>Total</h2>
                    </div>
                    
                    <div class="stats">
                        <h3>Your Quiz Performance</h3>
                        <div class="stat-box">
                            <p><strong>Total Quizzes Taken:</strong> {total_quizzes}</p>
                            <p><strong>Average Score:</strong> {avg_score:.1f}%</p>
                            {f"<p><strong>Your Ranking:</strong> {user_rank} out of {len(all_user_scores)}</p>" if user_rank else ""}
                        </div>
                    </div>
                    
                    <div class="subject-performance">
                        <h3>Subject Performance</h3>
                        <table>
                            <tr>
                                <th>Subject</th>
                                <th>Attempts</th>
                                <th>Average Score</th>
                            </tr>
                            {subject_rows}
                        </table>
                    </div>
                    
                    <div class="footer">
                        <p>This is an automated report from the Quiz App. Please do not reply to this email.</p>
                    </div>
                </div>
            </body>
            </html>
            """
            
            # Generate PDF from HTML
            pdf = HTML(string=html_content).write_pdf()
            
            # Send email with PDF attachment
            subject = f"Your Quiz Activity Report"
            send_email_with_attachment(
                to=user.email,
                subject=subject,
                html_content=html_content,
                attachment_data=pdf,
                attachment_filename="monthly_report.pdf",
                attachment_mimetype="application/pdf"
            )
        
        return f"Sent monthly reports to {len(users)} users"

@celery.task
def export_user_details_csv(admin_email):
    """Generate a CSV export of user details and quiz performance."""
    with current_app.app_context():
        output = StringIO()
        writer = csv.writer(output)
        
        writer.writerow([
            'User ID', 'Full Name', 'Email', 'Qualification', 
            'Quizzes Taken', 'Average Score', 'Last Quiz Date'
        ])
        

        users = User.query.filter_by(is_admin=False).all()
        
        for user in users:
            # Get user's scores
            user_scores = Score.query.filter_by(user_id=user.id).all()
            
            # Calculate statistics
            quizzes_taken = len(user_scores)
            avg_score = sum(score.percentage for score in user_scores) / quizzes_taken if quizzes_taken > 0 else 0
            
            # Get last quiz date
            last_quiz_date = max([score.time_stamp_of_attempt for score in user_scores]) if user_scores else None
            last_quiz_date_str = last_quiz_date.strftime('%Y-%m-%d %H:%M:%S') if last_quiz_date else 'Never'
            
            # Write user data
            writer.writerow([
                user.id,
                user.fullname,
                user.email,
                user.qualification,
                quizzes_taken,
                f"{avg_score:.1f}%",
                last_quiz_date_str
            ])
        
        # Get the CSV data
        csv_data = output.getvalue()
        
        # Send email with CSV attachment
        subject = "User Details CSV Export"
        html_content = """
        <html>
        <body>
            <h2>User Details CSV Export</h2>
            <p>Your requested CSV export of user details is attached.</p>
            <p>Best regards,<br>The Quiz App</p>
        </body>
        </html>
        """
        
        send_email_with_attachment(
            to=admin_email,
            subject=subject,
            html_content=html_content,
            attachment_data=csv_data,
            attachment_filename="user_details.csv",
            attachment_mimetype="text/csv"
        )
        
        return "CSV export completed and sent"

def send_email(to, subject, html_content):
    """Send a simple HTML email."""
    msg = MIMEMultipart()
    msg['From'] = 'quizapp@example.com'
    msg['To'] = to
    msg['Subject'] = subject
    
    msg.attach(MIMEText(html_content, 'html'))
    
    # For development with mailhog
    with smtplib.SMTP('localhost', 1025) as server:
        server.send_message(msg)

def send_email_with_attachment(to, subject, html_content, attachment_data, attachment_filename, attachment_mimetype):
    """Send an email with an attachment."""
    msg = MIMEMultipart()
    msg['From'] = 'quizapp@example.com'
    msg['To'] = to
    msg['Subject'] = subject
    
    # Attach HTML content
    msg.attach(MIMEText(html_content, 'html'))
    
    # Attach file
    attachment = MIMEBase(*attachment_mimetype.split('/'))
    attachment.set_payload(attachment_data)
    encoders.encode_base64(attachment)
    attachment.add_header(
        'Content-Disposition', f'attachment; filename={attachment_filename}'
    )
    msg.attach(attachment)
    
    # For development with mailhog
    with smtplib.SMTP('localhost', 1025) as server:
        server.send_message(msg)

# Configure periodic tasks
celery.conf.timezone = "Asia/Kolkata"
celery.conf.beat_schedule = {
    "daily-reminder-task": {
        "task": "tasks.send_daily_reminder",
        "schedule": crontab(hour=20, minute=0),  # 8 PM IST
    },
    "monthly-report-task": {
        "task": "tasks.send_monthly_report",
        "schedule": crontab(day_of_month=1, hour=0, minute=0),  # 1st of every month
    },
}


@celery.on_after_finalize.connect
def setup_periodic_tasks(sender, **kwargs):
    sender.add_periodic_task(20, send_daily_reminder.s(), name='Daily_Reminder') 
    sender.add_periodic_task(20, send_monthly_report.s(), name='Monthly_Report')
