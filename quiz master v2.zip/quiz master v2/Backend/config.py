from datetime import timedelta


class Config:
    SECRET_KEY = "keep it secret"
    SQLALCHEMY_DATABASE_URI = "sqlite:///db.sqlite3"  
    SQLALCHEMY_TRACK_MODIFICATIONS = False  
    JWT_ACCESS_TOKEN_EXPIRES= timedelta(hours=2)
    JWT_SECRET_KEY = "keep it secret"  
    DEBUG = True  
    CELERY_BROKER_URL = "redis://localhost:6379/0"
    CELERY_RESULT_BACKEND = "redis://localhost:6379/1"
    broker_url = "redis://localhost:6379/0"
    result_backend = "redis://localhost:6379/1"
    CACHE_TYPE = "RedisCache"
    CACHE_REDIS_HOST = "localhost"
    CACHE_REDIS_PORT = 6379
    CACHE_DEFAULT_TIMEOUT = 300

