from flask import Flask, render_template
from flask_jwt_extended import JWTManager
from models import db
from config import Config
import os
from datetime import datetime
from models import User
from routes import api
from werkzeug.security import generate_password_hash
import workers
import tasks

from routes import cache

app = Flask(__name__, template_folder=os.path.join(os.pardir, "frontend"),  static_folder=os.path.join(os.pardir, "frontend"))
app.config.from_object(Config)


db.init_app(app)
api.init_app(app)
cache.init_app(app)
jwt = JWTManager(app)

celery = workers.celery

celery.conf.update(
        broker_url='redis://localhost:6379',
        result_backend='redis://localhost:6379'
    )
celery.autodiscover_tasks(['tasks'])
celery.Task = workers.ContextTask
app.app_context().push()
app.app_context().push()

#creating a function to create an admin user
def create_admin():
    with app.app_context():
        admin_exists = User.query.filter_by(email="admin@gmail.com").first()
        if admin_exists:
            print("Admin already exists.") 
        else:
            admin = User(
                fullname="Admin Kumar",
                email="admin@gmail.com",
                password=generate_password_hash("1234"),
                dob=datetime.strptime("17-02-2000", "%d-%m-%Y").date(),
                qualification="BCA",
                is_admin=True 
            )
            db.session.add(admin)
            db.session.commit()
            print("Admin created successfully.") 


with app.app_context():
    db.create_all()
    create_admin()


@app.route("/")
def index():
    return render_template("index.html")

import time
@app.route('/testche')
@cache.cached(timeout=50)
def testingcache():
    time.sleep(10)
    return "Cached"


@app.route('/<path:path>')
def catch_all(path):
    return render_template("index.html")




if __name__ == "__main__":
    app.run()