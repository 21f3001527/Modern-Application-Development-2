from flask import Flask, request, jsonify
from flask_jwt_extended import JWTManager, jwt_required, create_access_token, get_jwt_identity
from models import db, User, Subject, Chapter, Quiz, Question, Score
from werkzeug.security import check_password_hash, generate_password_hash
from flask_restful import Resource, Api, reqparse
import json
from datetime import datetime
from flask_caching import Cache
from flask import current_app as app
from flask import request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy.orm import joinedload
from sqlalchemy import or_
import matplotlib.pyplot as plt
import base64
import io


api = Api()
cache = Cache()
# -------------------- Parsers --------------------
user_parser = reqparse.RequestParser()
user_parser.add_argument('email', type=str, required=True, help='Email is required')
user_parser.add_argument('password', type=str, required=True, help='Password is required')
user_parser.add_argument('fullname', type=str, required=True, help='Full name is required')
user_parser.add_argument('qualification', type=str)
user_parser.add_argument('dob', type=str)

user_login_parser = reqparse.RequestParser()
user_login_parser.add_argument('email', type=str, required=True, help='Email is required')
user_login_parser.add_argument('password', type=str, required=True, help='Password is required')

admin_login_parser = reqparse.RequestParser()
admin_login_parser.add_argument('email', type=str, required=True, help='Email is required')
admin_login_parser.add_argument('password', type=str, required=True, help='Password is required')

subject_parser = reqparse.RequestParser()
subject_parser.add_argument('name', type=str, required=True, help='Name is required')
subject_parser.add_argument('description', type=str)

chapter_parser = reqparse.RequestParser()
chapter_parser.add_argument('name', type=str, required=True, help='Name is required')
chapter_parser.add_argument('description', type=str)
chapter_parser.add_argument('subject_id', type=int, required=True, help='Subject ID is required')

quiz_parser = reqparse.RequestParser()
quiz_parser.add_argument('chapter_id', type=int, required=True, help='Chapter ID is required')
quiz_parser.add_argument('date_of_quiz', type=str, help='Date of quiz')
quiz_parser.add_argument('time_duration', type=int, help='Time duration in minutes')
quiz_parser.add_argument('status', type=str, choices=('active', 'archived'), default='active', help='Status must be "active" or "archived"')
quiz_parser.add_argument('remarks', type=str)

question_parser = reqparse.RequestParser()
question_parser.add_argument('question_statement', type=str, required=True, help="Question text is required")
question_parser.add_argument('quiz_id', type=int, required=True)
question_parser.add_argument('option1', type=str, required=True)
question_parser.add_argument('option2', type=str, required=True)
question_parser.add_argument('option3', type=str, required=True)
question_parser.add_argument('option4', type=str, required=True)
question_parser.add_argument('correct_option', type=int, required=True)
question_parser.add_argument('marks', type=float, default=1.0)


score_parser = reqparse.RequestParser()
score_parser.add_argument('quiz_id', type=int, required=True, help='Quiz ID is required')
score_parser.add_argument('user_id', type=int, required=True, help='User ID is required')
score_parser.add_argument('total_scored', type=int, required=True, help='Total scored is required')
score_parser.add_argument('total_questions', type=int, required=True, help='Total questions is required')
score_parser.add_argument('percentage', type=float, required=True, help='Percentage is required')

class UserRegister(Resource):
    def post(self):
        args = user_parser.parse_args()
        if User.query.filter_by(email=args['email']).first():
            return {"message": "User already exists"}, 400

        dob = datetime.strptime(args['dob'], "%Y-%m-%d").date() if args.get('dob') else None

        user = User(
            email=args['email'],
            password=generate_password_hash(args['password']),
            fullname=args['fullname'],
            qualification=args.get('qualification'),
            dob=dob
        )

        db.session.add(user)
        db.session.commit()
        return {"message": "User created successfully"}, 201


# # ADMIN LOGIN API
class AdminLogin(Resource):
    def post(self):
        try:
            data = request.get_json()
            email = data['email']
            password = data['password']
            
            print(f"Received email: {email}, password: {password}")

            # Query the user based on email
            user = User.query.filter_by(email=email, is_admin=True).first()

            if not user or not check_password_hash(user.password, password):
                return {
                    "message": "Invalid email or password",
                    "success": False
                }, 401

            # Create the access token if the credentials are valid
            access_token = create_access_token(identity=str(user.id), additional_claims={"role": "admin"})
            
            return{
                "message": "Login successful",
                "access_token": access_token
            }, 200
        
        except Exception as e:
            print(f"Error: {e}")
            return {
                "message": "An error occurred. Please try again later.",
                "success": False
            }, 500

# USER LOGIN API 
class UserLogin(Resource):
    def post(self):
        args = user_login_parser.parse_args()
        email = args['email']
        password = args['password']

        user = User.query.filter_by(email=email).first()
        if not user or user.is_admin or not check_password_hash(user.password, password):
            return {"message": "Invalid email or password"}, 401

        access_token = create_access_token(identity=str(user.id), additional_claims={"role": "user"})
        return {
            "message": "Login successful",
            "access_token": access_token,
            "role": "user"
        }, 200
# # -- Admin Dashboard ------
class AdminDashboard(Resource):
    @jwt_required()
    # @cache.cached(timeout=20)
    def get(self):
        user_id = int(get_jwt_identity())  # ✅ Ensure user is authenticated
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return jsonify({"message": "Unauthorized. Admin access required."}), 403
        
        subjects = Subject.query.order_by(Subject.created_at.desc()).all()

        return {
            "subjects": [
                {
                    "id": subject.id,
                    "name": subject.name,
                    "description": subject.description,
                    "created_at": subject.created_at.strftime('%Y-%m-%d')
                } for subject in subjects
            ],
        }, 200

# -------------------- Subject API --------------------
class SubjectResource(Resource):
    @jwt_required()
    def get(self):
        subjects = Subject.query.all()
        return {"subjects": [{"id": s.id, "name": s.name, "description": s.description} for s in subjects]}, 200

    @jwt_required()
    def post(self):
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403
        args = subject_parser.parse_args()
        if Subject.query.filter_by(name=args['name']).first():
            return {"message": "Subject already exists"}, 400
        subject = Subject(name=args['name'], description=args.get('description'))
        db.session.add(subject)
        db.session.commit()
        return {"message": "Subject created successfully", "id": subject.id}, 201

class OneSubjectResource(Resource):
    @jwt_required()
    def get(self, id):
        subject = Subject.query.get(id)
        if not subject:
            return {"message": "Subject not found"}, 404
        return {"id": subject.id, "name": subject.name, "description": subject.description}, 200

    @jwt_required()
    def put(self, id):
        # Fix identity handling
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403

        args = subject_parser.parse_args()
        subject = Subject.query.get(id)
        if not subject:
            return {"message": "Subject not found"}, 404

        subject.name = args['name']
        subject.description = args.get('description')
        db.session.commit()
        return {"message": "Subject updated successfully"}, 200
    
    @jwt_required()
    def delete(self, id):
        # Fix identity handling
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403

        subject = Subject.query.get(id)
        if not subject:
            return {"message": "Subject not found"}, 404

        db.session.delete(subject)
        db.session.commit()
        return {"message": "Subject deleted successfully"}, 200

# --- Chapter API ----
class ChapterResource(Resource):
    @jwt_required()
    def get(self):
        subject_id =  request.args.get('subject_id', type=int)
        
        if subject_id:
            chapters = Chapter.query.filter_by(subject_id=subject_id).all()
        else:
            chapters = Chapter.query.all()
            
        return {
            "chapters": [
                {"id": c.id, "name": c.name, "description": c.description, "subject_id": c.subject_id} 
                for c in chapters
            ]
        }, 200

    @jwt_required()
    def post(self):
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403
            
        args = chapter_parser.parse_args()
        chapter = Chapter(
            name=args['name'], 
            description=args.get('description'), 
            subject_id=args['subject_id']
        )
        db.session.add(chapter)
        db.session.commit()
        return {"message": "Chapter created successfully", "id": chapter.id}, 201

class OneChapterResource(Resource):
    @jwt_required()
    def get(self, id):
        chapter = Chapter.query.get(id)
        if not chapter:
            return {"message": "Chapter not found"}, 404

        return {
            "id": chapter.id, 
            "name": chapter.name, 
            "description": chapter.description, 
            "subject_id": chapter.subject_id
        }, 200

    @jwt_required()
    def put(self, id):
        # Fix identity handling
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403
            
        args = chapter_parser.parse_args()
        chapter = Chapter.query.get(id)
        if not chapter:
            return {"message": "Chapter not found"}, 404

        chapter.name = args['name']
        chapter.description = args.get('description')
        chapter.subject_id = args['subject_id']
        db.session.commit()
        return {"message": "Chapter updated successfully"}, 200


    @jwt_required()
    def delete(self, id):
        # Fix identity handling
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403
            
        chapter = Chapter.query.get(id)
        if not chapter:
            return {"message": "Chapter not found"}, 404

        db.session.delete(chapter)
        db.session.commit()
        return {"message": "Chapter deleted successfully"}, 200


# --- Quiz API ----
class QuizResource(Resource):
    @jwt_required()
    def get(self):
        # Use query params for filtering instead of request.json
        chapter_id = request.args.get('chapter_id', type=int)
        
        if chapter_id:
            quizzes = Quiz.query.filter_by(chapter_id=chapter_id).all()
        else:
            quizzes = Quiz.query.all()
            
        return jsonify({
            "quizzes": [
                {
                    "id": q.id,  
                    "chapter_id": q.chapter_id,
                    "date_of_quiz": q.date_of_quiz.strftime('%Y-%m-%d') if q.date_of_quiz else None,  
                    "time_duration": q.time_duration,
                    "status": q.status,
                    "remarks": q.remarks,
                    "created_at": q.created_at.strftime('%Y-%m-%d') if q.created_at else None,
                } for q in quizzes
            ]
        })
    @jwt_required()
    def post(self):
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403
            
        args = quiz_parser.parse_args()
        quiz = Quiz(
            chapter_id=args['chapter_id'],
            date_of_quiz=datetime.strptime(args['date_of_quiz'], "%Y-%m-%d").date() if args.get('date_of_quiz') else None,
            time_duration=args.get('time_duration'),
            status=args.get('status', 'active'),
            remarks=args.get('remarks'),

        )
        db.session.add(quiz)
        db.session.commit()
        return {"message": "Quiz created successfully", "id": quiz.id}, 201

class OneQuizResource(Resource):
    @jwt_required()
    def get(self, id):
        quiz = Quiz.query.get(id)
        if not quiz:
            return {"message": "Quiz not found"}, 404

        return {
            "id": quiz.id, 
            "chapter_id": quiz.chapter_id,
            "date_of_quiz": quiz.date_of_quiz.strftime('%Y-%m-%d') if quiz.date_of_quiz else None,
            "time_duration": quiz.time_duration,
            "status": quiz.status,
            "remarks": quiz.remarks
        }, 200

    @jwt_required()
    def put(self, id):
        # Fix identity handling
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403
            
        args = quiz_parser.parse_args()
        quiz = Quiz.query.get(id)
        if not quiz:
            return {"message": "Quiz not found"}, 404

        quiz.chapter_id = args['chapter_id']
        quiz.date_of_quiz = datetime.strptime(args['date_of_quiz'], "%Y-%m-%d").date()
        quiz.time_duration = args.get('time_duration', quiz.time_duration)
        quiz.status = args.get('status', quiz.status)
        quiz.remarks = args.get('remarks')
        db.session.commit()
        return {"message": "Quiz updated successfully"}, 200


    @jwt_required()
    def delete(self, id):
        # Fix1 identity handling
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403
            
        quiz = Quiz.query.get(id)
        if not quiz:
            return {"message": "Quiz not found"}, 404

        db.session.delete(quiz)
        db.session.commit()
        return {"message": "Quiz deleted successfully"}, 200

# - Question API -
class QuestionResource(Resource):
    @jwt_required()
    def get(self):
        # Use query params for filtering instead of request.json
        quiz_id = request.args.get('quiz_id', type=int)
        
        if quiz_id:
            questions = Question.query.filter_by(quiz_id=quiz_id).all()
        else:
            questions = Question.query.all()
            
        return {
            "questions": [
                {
                    "id": q.id, 
                    "question_statement": q.question_statement, 
                    "quiz_id": q.quiz_id,
                    "option1": q.option1,
                    "option2": q.option2,
                    "option3": q.option3,
                    "option4": q.option4,
                    "correct_option": q.correct_option,
                    "marks": q.marks
                } for q in questions
            ]
        }, 200
    @jwt_required()
    def post(self):
        # Fix identity handling
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403
            
        args = question_parser.parse_args()
        question = Question(
            question_statement=args['question_statement'],
            quiz_id=args['quiz_id'],
            option1=args['option1'],
            option2=args['option2'],
            option3=args['option3'],
            option4=args['option4'],
            correct_option=args['correct_option'],
            marks=args.get('marks', 1.0)
        )
        db.session.add(question)
        db.session.commit()
        return {"message": "Question created successfully", "id": question.id}, 201

class OneQuestionResource(Resource):
    @jwt_required()
    def get(self, id):
        question = Question.query.get(id)
        if not question:
            return {"message": "Question not found"}, 404

        return {
            "id": question.id, 
            "question_statement": question.question_statement,
            "quiz_id": question.quiz_id,
            "option1": question.option1,
            "option2": question.option2,
            "option3": question.option3,
            "option4": question.option4,
            "correct_option": question.correct_option,
            "marks": question.marks
        }, 200

    @jwt_required()
    def put(self, id):
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403
            
        args = question_parser.parse_args()
        question = Question.query.get(id)
        if not question:
            return {"message": "Question not found"}, 404

        question.question_statement = args.get('question_statement', question.question_statement)
        question.quiz_id = args.get('quiz_id', question.quiz_id)
        question.option1 = args.get('option1', question.option1)
        question.option2 = args.get('option2', question.option2)
        question.option3 = args.get('option3', question.option3)
        question.option4 = args.get('option4', question.option4)
        question.correct_option = args.get('correct_option', question.correct_option)
        question.marks = args.get('marks', question.marks)
        db.session.commit()
        return {"message": "Question updated successfully"}, 200
    
    @jwt_required()
    def delete(self, id):
        # Fix identity handling
        user_id = int(get_jwt_identity())
        user = User.query.get(user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403
            
        question = Question.query.get(id)
        if not question:
            return {"message": "Question not found"}, 404

        db.session.delete(question)
        db.session.commit()
        return {"message": "Question deleted successfully"}, 200
        
# user logout
class UserLogout(Resource):
    @jwt_required()
    def post(self):
        return {"message": "Successfully logged out"}, 200

class UserDashboardResource(Resource):
    @jwt_required()
    def get(self):
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return {"message": "User not found"}, 404
        
        if user.is_admin:
            return {"message": "Only users can access this endpoint"}, 403
        
        # Fetch available quizzes
        quizzes = Quiz.query.all()
        quiz_data = []
        
        for quiz in quizzes:
            chapter_name = quiz.chapter.name if quiz.chapter else '-'
            subject_name = quiz.chapter.subject.name if quiz.chapter and quiz.chapter.subject else '-'
            
            quiz_data.append({
                "id": quiz.id,
                "chapter_id": quiz.chapter_id,
                "date_of_quiz": quiz.date_of_quiz.strftime('%Y-%m-%d') if quiz.date_of_quiz else None,
                "time_duration": quiz.time_duration,
                "status": quiz.status,
                "remarks": quiz.remarks,
                "chapter_name": chapter_name,
                "subject_name": subject_name
            })
        
        scores = Score.query.filter_by(user_id=user.id).order_by(Score.time_stamp_of_attempt.desc()).all()
        score_data = []
        
        for score in scores:
            score_data.append({
                "id": score.id,
                "quiz_id": score.quiz_id,
                "total_scored": score.total_scored,
                "total_questions": score.total_questions,
                "percentage": score.percentage,
                "time_stamp_of_attempt": score.time_stamp_of_attempt.strftime('%Y-%m-%d %H:%M:%S'),
                "quiz_date": score.quiz.date_of_quiz.strftime('%Y-%m-%d') if score.quiz and score.quiz.date_of_quiz else None
            })
        
        return {
            "user": {
                "id": user.id,
                "fullname": user.fullname,
                "email": user.email,
                "qualification": user.qualification,
                "dob": user.dob.strftime('%Y-%m-%d') if user.dob else None
            },
            "quizzes": quiz_data,
            "scores": score_data
        }, 200

class UserProfileResource(Resource):
    @jwt_required()
    def get(self):
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return {"message": "User not found"}, 404
            
        return {
            "id": user.id,
            "fullname": user.fullname,
            "email": user.email,
            "dob": user.dob.strftime('%Y-%m-%d') if user.dob else None,
            "qualification": user.qualification
        }, 200
        
    @jwt_required()
    def put(self):
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return {"message": "User not found"}, 404
            
        data = request.get_json()
        
        try:
            if 'fullname' in data:
                user.fullname = data['fullname']
            if 'dob' in data:
                user.dob = datetime.strptime(data['dob'], "%Y-%m-%d").date()
            if 'qualification' in data:
                user.qualification = data['qualification']
                
            db.session.commit()
            return {"message": "Profile updated successfully"}, 200
        except Exception as e:
            db.session.rollback()
            return {"message": f"Error updating profile: {str(e)}"}, 500


class QuizAttemptResource(Resource):
    @jwt_required()
    def get(self, quiz_id):
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return {"message": "User not found"}, 404
            
        quiz = Quiz.query.options(joinedload(Quiz.questions)).filter_by(id=quiz_id).first()
        
        if not quiz:
            return {"message": "Quiz not found"}, 404
            
        questions = []
        for q in quiz.questions:
            questions.append({
                "id": q.id,
                "question_statement": q.question_statement,
                "option1": q.option1,
                "option2": q.option2,
                "option3": q.option3,
                "option4": q.option4,
                "marks": q.marks
            })
            
        return {
            "quiz": {
                "id": quiz.id,
                # Remove the 'name' field or replace it with an appropriate field
                "chapter_id": quiz.chapter_id,
                "date_of_quiz": quiz.date_of_quiz.strftime('%Y-%m-%d') if quiz.date_of_quiz else None,
                "time_duration": quiz.time_duration,
                "status": quiz.status,
                "remarks": quiz.remarks
            },
            "questions": questions
        }, 200

        
    @jwt_required()
    def post(self, quiz_id):
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return {"message": "User not found"}, 404
            
        quiz = Quiz.query.options(joinedload(Quiz.questions)).filter_by(id=quiz_id).first()
        
        if not quiz:
            return {"message": "Quiz not found"}, 404
            
        total_questions = len(quiz.questions)
        
        if total_questions == 0:
            return {"message": "This quiz has no questions!"}, 400
            
        data = request.get_json()
        answers = data.get('answers', {})
        
        score = 0
        for i, question in enumerate(quiz.questions):
            question_key = str(question.id)
            if question_key in answers:
                user_answer = int(answers[question_key])
                if user_answer == question.correct_option:
                    score += 1
                    
        percentage_score = (score / total_questions) * 100 if total_questions > 0 else 0
        
        new_score = Score(
            user_id=user.id,
            quiz_id=quiz.id,
            total_scored=score,
            total_questions=total_questions,
            percentage=percentage_score,
            time_stamp_of_attempt=datetime.now()
        )
        
        try:
            db.session.add(new_score)
            db.session.commit()
            return {
                "message": "Quiz completed successfully",
                "score": {
                    "total_scored": score,
                    "total_questions": total_questions,
                    "percentage": percentage_score
                }
            }, 201
        except Exception as e:
            db.session.rollback()
            return {"message": f"Error recording score: {str(e)}"}, 500


class SearchResource(Resource):
    @jwt_required()
    def get(self):
        search_query = request.args.get("q", "")
        
        if not search_query:
            return {
                "users": [],
                "subjects": [],
                "chapters": [],
                "quizzes": []
            }, 200
            
        users = User.query.filter(User.fullname.like(f"%{search_query}%")).all()
        subjects = Subject.query.filter(Subject.name.like(f"%{search_query}%")).all()
        chapters = Chapter.query.filter(Chapter.name.like(f"%{search_query}%")).all()
        quizzes = Quiz.query.filter(Quiz.remarks.like(f"%{search_query}%")).all()
        
        return {
            "users": [{"id": u.id, "fullname": u.fullname, "email": u.email} for u in users],
            "subjects": [{"id": s.id, "name": s.name} for s in subjects],
            "chapters": [{"id": c.id, "name": c.name, "subject_id": c.subject_id} for c in chapters],
            "quizzes": [{"id": q.id, "name": q.remarks, "chapter_id": q.chapter_id} for q in quizzes]
        }, 200

class UserSearchResource(Resource):
    @jwt_required()
    def get(self):
        search_query = request.args.get('q', '')
        
        quizzes = Quiz.query.join(Chapter).join(Subject).filter(
            or_(
                Quiz.remarks.ilike(f'%{search_query}%'),
                Chapter.name.ilike(f'%{search_query}%'),
                Subject.name.ilike(f'%{search_query}%')
            )
        ).all()
        
        quiz_data = [{
            "id": quiz.id,
            "remarks": quiz.remarks,
            "date_of_quiz": quiz.date_of_quiz.strftime('%Y-%m-%d') if quiz.date_of_quiz else None,
            "time_duration": quiz.time_duration,
            "chapter_name": quiz.chapter.name if quiz.chapter else None,
            "subject_name": quiz.chapter.subject.name if quiz.chapter and quiz.chapter.subject else None
        } for quiz in quizzes]
        
        return {"quizzes": quiz_data}, 200


class AdminSummaryResource(Resource):
    @jwt_required()
    def get(self):
        # Check if user is admin
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403
            
        try:
            # Basic statistics
            total_users = User.query.count()
            total_subjects = Subject.query.count()
            total_scores = Score.query.count()
            
            # Get subjects and calculate quizzes
            subjects = Subject.query.all()
            total_quizzes = 0
            quiz_count_dict = {}
            
            for subject in subjects:
                quiz_count = 0
                for chapter in subject.chapters:
                    quiz_count += len(chapter.quizzes)
                quiz_count_dict[subject.name] = quiz_count
                total_quizzes += quiz_count
            
            plt.figure(figsize=(10, 6))
            plt.bar(list(quiz_count_dict.keys()), list(quiz_count_dict.values()))
            plt.title('Quizzes per Subject')
            plt.xlabel('Subjects')
            plt.ylabel('Number of Quizzes')
            plt.xticks(rotation=45)
            plt.tight_layout()
            
            # Save to buffer
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png')
            buffer.seek(0)
            plot_url = base64.b64encode(buffer.getvalue()).decode()
            plt.close()
            
            # Get recent scores
            recent_scores = Score.query.order_by(Score.time_stamp_of_attempt.desc()).limit(5).all()
            recent_scores_data = [{
                "id": score.id,
                "user_name": score.user.fullname if score.user else "Unknown",
                "quiz_id": score.quiz_id,
                "quiz_name": score.quiz.remarks if score.quiz else "Unknown",
                "percentage": score.percentage,
                "time_stamp": score.time_stamp_of_attempt.strftime('%Y-%m-%d %H:%M:%S')
            } for score in recent_scores]
            
            # Get subject details
            subject_details = [{
                "id": subject.id,
                "name": subject.name,
                "chapter_count": len(subject.chapters),
                "quiz_count": quiz_count_dict.get(subject.name, 0)
            } for subject in subjects]
            
            return {
                "statistics": {
                    "total_users": total_users,
                    "total_subjects": total_subjects,
                    "total_quizzes": total_quizzes,
                    "total_scores": total_scores
                },
                "plot_url": plot_url,
                "recent_scores": recent_scores_data,
                "subject_details": subject_details,
                "quiz_count_per_subject": quiz_count_dict
            }, 200
            
        except Exception as e:
            return {"message": f"An error occurred: {str(e)}"}, 500



class UserSummaryResource(Resource):
    @jwt_required()
    def get(self):
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user:
            return {"message": "User not found"}, 404
            
        try:
            scores = Score.query.filter_by(user_id=user.id).all()

            if not scores:
                return {"message": "No quiz attempts found"}, 404

            # Basic stats
            total_attempts = len(scores)
            avg_score = sum(score.percentage for score in scores) / total_attempts

            subject_data = {}
            for score in scores:
                quiz = Quiz.query.get(score.quiz_id)
                if not quiz:
                    continue
                    
                chapter = Chapter.query.get(quiz.chapter_id)
                if not chapter:
                    continue
                    
                subject = Subject.query.get(chapter.subject_id)
                if not subject:
                    continue
                
                if subject.name not in subject_data:
                    subject_data[subject.name] = {
                        'attempts': 0,
                        'scores': []
                    }
                subject_data[subject.name]['attempts'] += 1
                subject_data[subject.name]['scores'].append(score.percentage)

            # Calculate averages
            for subject in subject_data.values():
                subject['avg_score'] = sum(subject['scores']) / len(subject['scores'])

            # Create bar chart for subject scores
            plt.figure(figsize=(10, 5))
            subjects = list(subject_data.keys())
            scores_avg = [data['avg_score'] for data in subject_data.values()]
            plt.bar(subjects, scores_avg)
            plt.title('Average Scores by Subject')
            plt.xticks(rotation=45)
            plt.ylim(0, 100)  # Assuming scores are out of 100
            plt.ylabel('Average Score (%)')
            plt.tight_layout()

            # Save bar chart
            score_buffer = io.BytesIO()
            plt.savefig(score_buffer, format='png', bbox_inches='tight')
            plt.close()
            score_buffer.seek(0)
            score_chart = base64.b64encode(score_buffer.getvalue()).decode()

            # Create pie chart for attempt distribution
            plt.figure(figsize=(8, 8))
            attempts_count = [data['attempts'] for data in subject_data.values()]
            plt.pie(attempts_count, labels=subjects, autopct='%1.1f%%')
            plt.title('Distribution of Attempts by Subject')
            plt.tight_layout()

            # Save pie chart
            attempt_buffer = io.BytesIO()
            plt.savefig(attempt_buffer, format='png', bbox_inches='tight')
            plt.close()
            attempt_buffer.seek(0)
            attempt_chart = base64.b64encode(attempt_buffer.getvalue()).decode()

            # Format subject data for response
            subject_data_formatted = {}
            for subject_name, data in subject_data.items():
                subject_data_formatted[subject_name] = {
                    'attempts': data['attempts'],
                    'avg_score': round(data['avg_score'], 1)
                }

            return {
                "total_attempts": total_attempts,
                "avg_score": round(avg_score, 1),
                "subject_data": subject_data_formatted,
                "score_chart": score_chart,
                "attempt_chart": attempt_chart
            }, 200
            
        except Exception as e:
            return {"message": f"An error occurred: {str(e)}"}, 500

class ExportCSVResource(Resource):
    @jwt_required()
    def get(self):
        # Check if user is admin
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        if not user or not user.is_admin:
            return {"message": "Admin access required"}, 403
        
        # Trigger the CSV export task
        from tasks import export_user_details_csv
        task = export_user_details_csv.delay(user.email)
        
        return {
            "message": "CSV export started. You will receive an email when it's ready.",
            "task_id": str(task.id)
        }, 202

# Register all resources
api.add_resource(UserRegister, "/api/user/register")
api.add_resource(UserLogin, '/api/user/login')
api.add_resource(AdminLogin, '/api/admin/login')
api.add_resource(AdminDashboard, "/api/admin/dashboard")
api.add_resource(SubjectResource, "/api/admin/subjects")
api.add_resource(OneSubjectResource, "/api/admin/subjects/<int:id>")
api.add_resource(ChapterResource, "/api/admin/chapters")
api.add_resource(OneChapterResource, "/api/admin/chapters/<int:id>")
api.add_resource(QuizResource, "/api/admin/quizzes")
api.add_resource(OneQuizResource, "/api/admin/quizzes/<int:id>")
api.add_resource(QuestionResource, "/api/admin/questions")
api.add_resource(OneQuestionResource, "/api/admin/questions/<int:id>")
api.add_resource(UserDashboardResource, '/api/user/dashboard')
api.add_resource(UserLogout, "/api/logout") 
api.add_resource(UserProfileResource, "/api/user/profile")
api.add_resource(QuizAttemptResource, "/api/user/attempt/<int:quiz_id>")
api.add_resource(SearchResource, "/api/search")
api.add_resource(UserSearchResource, "/api/user/search")
api.add_resource(AdminSummaryResource, '/api/admin/summary')
api.add_resource(UserSummaryResource, '/api/user/summary')
api.add_resource(ExportCSVResource, '/api/admin/export-csv')
