import AdminLogin from "./components/admin_login.js";
import AdminDashboard from "./components/admin_dashboard.js";
import Home from './components/home.js';
import UserRegister from './components/user_register.js'
import UserDashboard from "./components/user_dashboard.js";
import UserLogin from "./components/user_login.js"
import CreateSubject from './components/create_subject.js';
import EditSubject from './components/edit_subject.js';
import ViewSubject from './components/view_subject.js';
import CreateChapter from './components/create_chapter.js';
import EditChapter from './components/edit_chapter.js';
import ViewChapter from './components/view_chapter.js';
import CreateQuiz from './components/create_quiz.js';
import EditQuiz from './components/edit_quiz.js';
import ViewQuiz from './components/view_quiz.js';
import CreateQuestion from './components/create_question.js';
import EditQuestion from './components/edit_question.js';
import Search from './components/search.js';
import UserProfile from "./components/user_profile.js";
import QuizAttempt from "./components/quiz_attempt.js";
import UserSearch from "./components/user_search.js";
import AdminSummary from "./components/admin_summary.js";
import UserSummary from "./components/user_summary.js";




const routes = [
    { path: '/', component: Home },
    { path: '/admin/login', component: AdminLogin },
    { path: '/user/login', component: UserLogin },
    { path: '/register', component: UserRegister },
    { path: '/admin/dashboard', component: AdminDashboard },
    { path: '/user/dashboard', component: UserDashboard },
    { path: '/view_subject/:subjectId', component: ViewSubject },
    { path: '/create_subject', component: CreateSubject },
    { path: '/edit_subject/:id', component: EditSubject },
    { path: '/view_chapter/:chapterId', component: ViewChapter },
    { path: '/:subjectId/create_chapter', component: CreateChapter },
    { path: '/:subjectId/edit_chapter/:chapterId', component: EditChapter },
    { path: '/view_quiz/:quizId', component: ViewQuiz },
    { path: '/:chapterId/create_quiz', component: CreateQuiz },
    { path: '/:chapterId/edit_quiz/:quizId', component: EditQuiz },
    { path: '/create_question/:quizId', component: CreateQuestion },
    { path: '/edit_question/:id', component: EditQuestion },
    { path: '/search', component: Search },
    { path: '/user/profile', component: UserProfile },
    { path: '/user/attempt/:quizId', component: QuizAttempt },
    { path: '/user/search', component: UserSearch },
    { path: '/admin/summary', component: AdminSummary },
    { path: '/user/summary', component: UserSummary },
    {path: '/:catchAll(.*)', redirect: '/' },
];

const router = VueRouter.createRouter({
    history: VueRouter.createWebHistory(),
    routes,
});

const app = Vue.createApp({});
app.use(router);
app.mount('#app');

