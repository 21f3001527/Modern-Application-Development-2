const AdminLogin = {
  template: `
      <div class="container mt-5">
          <h2>Admin Login</h2>
          <form @submit.prevent="login">
              <div class="mb-3">
                  <label class="form-label">Email</label>
                  <input type="email" v-model="email" class="form-control" required>
              </div>
              <div class="mb-3">
                  <label class="form-label">Password</label>
                  <input type="password" v-model="password" class="form-control" required>
              </div>
              <button type="submit" class="btn btn-primary">Login as Admin</button>
          </form>
      </div>
  `,
  data() {
    return {
        email: '',
        password: '',
    };
},
methods: {
    async login() {
        try {
            const response = await fetch('/api/admin/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: this.email,
                    password: this.password,
                }),
            });
            const data = await response.json();
            if (response.ok) {
               
                localStorage.setItem('token', data.access_token);

               
                if (data.message === "Login successful") {
                    alert(data.message);
                    this.$router.push('/admin/dashboard');
                }
            } else {
                alert(data.message || 'Login failed');
            }
        } catch (error) {
            console.error('Error logging in:', error);
            alert('An error occurred during login');
    
    }
    },
},
};

export default AdminLogin;