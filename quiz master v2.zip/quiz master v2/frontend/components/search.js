const Search = {
    template: `
      <nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top">
      <div class="container-fluid">
        <a class="navbar-brand" href="/admin">Quiz Master</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav me-auto">
            <a class="nav-link active" href="/admin/dashboard">Dashboard</a>
            <a class="nav-link" href="/admin/summary">Summary</a>
            <a class="nav-link" href="/search">Search</a>
            <a class="nav-link" href="/create_subject">Create Subject</a>
          </div>
          <div class="navbar-nav">
            <button class="nav-link btn btn-danger text-white ms-2" @click="logout">Logout</button>
          </div>
        </div>
      </div>
    </nav>
      <div class="container my-4">
        <!-- Search Form -->
        <div class="row mb-4">
          <div class="col-md-8 mx-auto">
            <form @submit.prevent="performSearch" class="d-flex">
              <input type="text" v-model="searchQuery" class="form-control me-2" 
                    placeholder="Search for users, subjects, chapters, or quizzes...">
              <button type="submit" class="btn btn-primary">Search</button>
            </form>
          </div>
        </div>
  
        <!-- Search Results -->
        <div class="row">
          <!-- Users Section -->
          <div class="col-md-6 mb-4">
            <div class="card">
              <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Users</h5>
                <span class="badge bg-secondary">{{ users.length }}</span>
              </div>
              <div class="card-body">
                <div v-if="users.length">
                  <ul class="list-group list-group-flush">
                    <li v-for="user in users" :key="user.id" class="list-group-item">
                      <h6 class="mb-0">{{ user.fullname }}</h6>
                      <small class="text-muted">ID: {{ user.id }}</small><br>
                      <small class="text-muted">Email: {{ user.email }}</small>
                    </li>
                  </ul>
                </div>
                <p v-else class="text-muted">No users found</p>
              </div>
            </div>
          </div>
  
          <!-- Subjects Section -->
          <div class="col-md-6 mb-4">
            <div class="card">
              <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Subjects</h5>
                <span class="badge bg-secondary">{{ subjects.length }}</span>
              </div>
              <div class="card-body">
                <div v-if="subjects.length">
                  <ul class="list-group list-group-flush">
                    <li v-for="subject in subjects" :key="subject.id" class="list-group-item">
                      <a @click="viewSubject(subject.id)" href="#" class="text-decoration-none">
                        <h6 class="mb-0">{{ subject.name }}</h6>
                        <small class="text-muted">ID: {{ subject.id }}</small>
                      </a>
                    </li>
                  </ul>
                </div>
                <p v-else class="text-muted">No subjects found</p>
              </div>
            </div>
          </div>
  
          <!-- Chapters Section -->
          <div class="col-md-6 mb-4">
            <div class="card">
              <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Chapters</h5>
                <span class="badge bg-secondary">{{ chapters.length }}</span>
              </div>
              <div class="card-body">
                <div v-if="chapters.length">
                  <ul class="list-group list-group-flush">
                    <li v-for="chapter in chapters" :key="chapter.id" class="list-group-item">
                      <a @click="viewChapter(chapter.subject_id, chapter.id)" href="#" class="text-decoration-none">
                        <h6 class="mb-0">{{ chapter.name }}</h6>
                        <small class="text-muted">
                          ID: {{ chapter.id }} | 
                          Subject ID: {{ chapter.subject_id }}
                        </small>
                      </a>
                    </li>
                  </ul>
                </div>
                <p v-else class="text-muted">No chapters found</p>
              </div>
            </div>
          </div>
  
          <!-- Quizzes Section -->
          <div class="col-md-6 mb-4">
            <div class="card">
              <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Quizzes</h5>
                <span class="badge bg-secondary">{{ quizzes.length }}</span>
              </div>
              <div class="card-body">
                <div v-if="quizzes.length">
                  <ul class="list-group list-group-flush">
                    <li v-for="quiz in quizzes" :key="quiz.id" class="list-group-item">
                      <a @click="viewQuiz(quiz.chapter_id, quiz.id)" href="#" class="text-decoration-none">
                        <h6 class="mb-0">{{ quiz.name }}</h6>
                        <small class="text-muted">
                          ID: {{ quiz.id }} | 
                          Chapter ID: {{ quiz.chapter_id }}
                        </small>
                      </a>
                    </li>
                  </ul>
                </div>
                <p v-else class="text-muted">No quizzes found</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
    data() {
      return {
        searchQuery: '',
        users: [],
        subjects: [],
        chapters: [],
        quizzes: []
      }
    },
    methods: {
      async performSearch() {
        try {
          const response = await fetch(`/api/search?q=${encodeURIComponent(this.searchQuery)}`, {
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
          });
          if (response.ok) {
            const data = await response.json();
            this.users = data.users;
            this.subjects = data.subjects;
            this.chapters = data.chapters;
            this.quizzes = data.quizzes;
          } else {
            console.error('Failed to perform search');
          }
        } catch (error) {
          console.error('Error:', error);
        }
      },
      viewSubject(subjectId) {
        this.$router.push(`/view_subject/${subjectId}`);
      },
      viewChapter(subjectId, chapterId) {
        this.$router.push(`/view_chapter/${chapterId}`);
      },
      viewQuiz(chapterId, quizId) {
        this.$router.push(`/view_quiz/${quizId}`);
      },
      logout() {
        localStorage.removeItem('token');
        this.$router.push('/');
      }
    },
    mounted() {
      // If there's a query parameter in the URL, use it to search
      const urlParams = new URLSearchParams(window.location.search);
      const queryParam = urlParams.get('q');
      if (queryParam) {
        this.searchQuery = queryParam;
        this.performSearch();
      }
    }
  };
  
  export default Search;
  