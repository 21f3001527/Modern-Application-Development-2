const UserSearch = {
    template: `
    <div>
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container-fluid">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#" @click.prevent="goToDashboard">Dashboard</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#" @click.prevent="goToSearch">Search Quizzes</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#" @click.prevent="goToSummary">Summary</a>
              </li>
            </ul>
            <button class="btn btn-outline-danger" @click="logout">Logout</button>
          </div>
        </div>
      </nav>
      <!-- Content -->
      <div class="container mt-5">
        <h2 class="text-center mb-4">Search Quizzes</h2>
        <div class="row justify-content-center">
          <div class="col-md-6">
            <input 
              v-model="searchQuery" 
              type="text" 
              class="form-control" 
              placeholder="Search for quizzes..."
            >
          </div>
        </div>
        <div class="row mt-4">
          <div class="col-12">
            <div v-if="loading" class="text-center">
              <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
              </div>
            </div>
            <div v-else-if="quizzes.length" class="list-group">
              <a 
                v-for="quiz in quizzes" 
                :key="quiz.id" 
                @click.prevent="attemptQuiz(quiz.id)"
                href="#" 
                class="list-group-item list-group-item-action"
              >
                <div class="d-flex w-100 justify-content-between">
                  <h5 class="mb-1">{{ quiz.remarks }}</h5>
                  <small>{{ quiz.date_of_quiz }}</small>
                </div>
                <p class="mb-1">{{ quiz.chapter_name }} - {{ quiz.subject_name }}</p>
                <small>Duration: {{ quiz.time_duration }} minutes</small>
              </a>
            </div>
            <p v-else class="text-center">No quizzes found.</p>
          </div>
        </div>
      </div>
    `,
    data() {
      return {
        searchQuery: '',
        quizzes: [],
        loading: false,
        debounceTimeout: null
      };
    },
    watch: {
      searchQuery() {
        clearTimeout(this.debounceTimeout);
        this.debounceTimeout = setTimeout(() => {
          this.searchQuizzes();
        }, 300);
      }
    },
    methods: {
      async searchQuizzes() {
        this.loading = true;
        try {
          const response = await fetch(`/api/user/search?q=${encodeURIComponent(this.searchQuery)}`, {
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
          });
          if (response.ok) {
            const data = await response.json();
            this.quizzes = data.quizzes;
          } else {
            console.error('Failed to fetch quizzes');
          }
        } catch (error) {
          console.error('Error:', error);
        } finally {
          this.loading = false;
        }
      },
      attemptQuiz(quizId) {
        this.$router.push(`/user/attempt/${quizId}`);
      },
      goToDashboard() {
        // If already on dashboard, do nothing; otherwise, navigate to dashboard
        if (this.$route.path !== '/user/dashboard') {
          this.$router.push('/user/dashboard');
        }
      },
      goToSearch() {
        this.$router.push('/user/search');
      },
      goToSummary() {
        this.$router.push('/user/summary');
      },
      logout() {
        // Clear the token from localStorage
        localStorage.removeItem('token');
        // Redirect to login page
        this.$router.push('/');
      }
    },
    mounted() {
      this.searchQuizzes();
    }
  };
  
  export default UserSearch;
  