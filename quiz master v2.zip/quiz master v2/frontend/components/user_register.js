const UserRegister = {
  template: `
      <div class="container mt-5">
          <h2>User Registration</h2>
          <form @submit.prevent="register">
              <div class="mb-3">
                  <label class="form-label">Full Name</label>
                  <input type="text" v-model="fullname" class="form-control" required>
              </div>
              <div class="mb-3">
                  <label class="form-label">Email</label>
                  <input type="email" v-model="email" class="form-control" required>
              </div>
              <div class="mb-3">
                  <label class="form-label">Password</label>
                  <input type="password" v-model="password" class="form-control" required>
              </div>
              <div class="mb-3">
                  <label class="form-label">Qualification</label>
                  <input type="text" v-model="qualification" class="form-control">
              </div>
              <div class="mb-3">
                  <label class="form-label">Date of Birth</label>
                  <input type="date" v-model="dob" class="form-control">
              </div>
              <button type="submit" class="btn btn-success">Register</button>
          </form>
      </div>
  `,
  data() {
      return { fullname: '', email: '', password: '', qualification: '', dob: '' };
  },
  methods: {
      register() {
          fetch('/api/user/register', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                  fullname: this.fullname,
                  email: this.email,
                  password: this.password,
                  qualification: this.qualification,
                  dob: this.dob
              })
          })
          .then(response => response.json())
          .then(data => {
              alert(data.message);
              if (data.message === "User created successfully") {
                  this.$router.push('/dashboard');
              }
          })
          .catch(error => alert("Error: " + error));
      }
  }
};
export default UserRegister;