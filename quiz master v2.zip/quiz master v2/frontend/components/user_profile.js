const UserProfile = {
    template: `
      <div class="container mt-5">
        <h2 class="text-center">Edit Profile</h2>
        <form @submit.prevent="updateProfile">
          <div class="form-group mb-3">
            <label for="fullname">Full Name</label>
            <input type="text" class="form-control" id="fullname" v-model="user.fullname" required>
          </div>
          <div class="form-group mb-3">
            <label for="dob">Date of Birth</label>
            <input type="date" class="form-control" id="dob" v-model="user.dob" required>
          </div>
          <div class="form-group mb-3">
            <label for="qualification">Qualification</label>
            <input type="text" class="form-control" id="qualification" v-model="user.qualification" required>
          </div>
          <button type="submit" class="btn btn-primary">Update Profile</button>
          <button type="button" @click="goBack" class="btn btn-secondary ms-2">Cancel</button>
        </form>
      </div>
    `,
    data() {
      return {
        user: {
          fullname: '',
          dob: '',
          qualification: ''
        }
      }
    },
    methods: {
      async fetchProfile() {
        try {
          const response = await fetch('/api/user/profile', {
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
          });
          if (response.ok) {
            const data = await response.json();
            this.user = data;
          } else {
            console.error('Failed to fetch profile');
          }
        } catch (error) {
          console.error('Error:', error);
        }
      },
      async updateProfile() {
        try {
          const response = await fetch('/api/user/profile', {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify(this.user)
          });
          if (response.ok) {
            alert('Profile updated successfully');
            this.$router.push('/user/dashboard');
          } else {
            console.error('Failed to update profile');
          }
        } catch (error) {
          console.error('Error:', error);
        }
      },
      goBack() {
        this.$router.push('/user/dashboard');
      }
    },
    mounted() {
      this.fetchProfile();
    }
  };
  
  export default UserProfile;
  