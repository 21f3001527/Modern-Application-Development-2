const EditQuestion = {
  template: `
    <div class="container mt-4">
      <div class="card">
        <div class="card-header bg-warning">
          <h3>Edit Question</h3>
        </div>
        <div class="card-body">
          <form @submit.prevent="updateQuestion">
            <div class="form-group mb-3">
              <label for="question_statement">Question:</label>
              <textarea class="form-control" id="question_statement" v-model="question.question_statement" 
                        rows="3" required></textarea>
            </div>

            <div class="form-group mb-3">
              <label for="option1">Option 1:</label>
              <input type="text" class="form-control" id="option1" v-model="question.option1" required>
            </div>

            <div class="form-group mb-3">
              <label for="option2">Option 2:</label>
              <input type="text" class="form-control" id="option2" v-model="question.option2" required>
            </div>

            <div class="form-group mb-3">
              <label for="option3">Option 3:</label>
              <input type="text" class="form-control" id="option3" v-model="question.option3" required>
            </div>

            <div class="form-group mb-3">
              <label for="option4">Option 4:</label>
              <input type="text" class="form-control" id="option4" v-model="question.option4" required>
            </div>

            <div class="form-group mb-3">
              <label for="correct_option">Correct Option:</label>
              <select class="form-control" id="correct_option" v-model="question.correct_option" required>
                <option value="1">Option 1</option>
                <option value="2">Option 2</option>
                <option value="3">Option 3</option>
                <option value="4">Option 4</option>
              </select>
            </div>

            <div class="form-group mb-3">
              <label for="marks">Marks:</label>
              <input type="number" class="form-control" id="marks" v-model="question.marks" required>
            </div>

            <button type="submit" class="btn btn-warning">Update Question</button>
            <button @click="goBack" class="btn btn-secondary">Cancel</button>
          </form>
        </div>
      </div>
    </div>
  `,
  data() {
    return {
      question: {
        id: null,
        question_statement: '',
        option1: '',
        option2: '',
        option3: '',
        option4: '',
        correct_option: '',
        marks: 1.0,
        quiz_id: null
      }
    }
  },
  methods: {
    async fetchQuestion() {
      try {
        const response = await fetch(`/api/admin/questions/${this.$route.params.id}`, {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        if (response.ok) {
          const data = await response.json();
          this.question = data;
        } else {
          console.error('Failed to fetch question');
        }
      } catch (error) {
        console.error('Error:', error);
      }
    },
    async updateQuestion() {
      try {
        const response = await fetch(`/api/admin/questions/${this.question.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          },
          body: JSON.stringify(this.question)
        });
        if (response.ok) {
          alert('Question updated successfully');
          this.$router.push(`/view_quiz/${this.question.quiz_id}`);
        } else {
          console.error('Failed to update question');
        }
      } catch (error) {
        console.error('Error:', error);
      }
    },
    goBack() {
      this.$router.push(`/view_quiz/${this.question.quiz_id}`);
    }
  },
  mounted() {
    this.fetchQuestion();
  }
};

export default EditQuestion;
