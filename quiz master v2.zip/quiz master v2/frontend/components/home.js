const Home = {
  template: `
  <div class="container-fluid vh-100 d-flex align-items-center justify-content-center">
      <div class="text-center">
          <h1 class="mb-3">Welcome to Quiz Master</h1>
          <p class="lead mb-4">Prepare, practice, and improve your knowledge.</p>
          <div class="d-flex justify-content-center gap-3">
              <router-link to="/admin/login" class="btn btn-primary">Admin Login</router-link>
              <router-link to="/user/login" class="btn btn-primary">User Login</router-link>
            
          </div>
      </div>
  </div>
  `,
};

export default Home;
