const ViewChapter = {
  template: `
  <div>
    <!-- Main Content -->
    <div class="container">
      <h1>Quizzes</h1>
      <div v-if="quizzes.length === 0">
        <p>No quizzes found.</p>
      </div>
      <div v-else>
        <table class="table table-striped">
          <thead>
            <tr>
              <th>Date of Quiz</th>
              <th>Time Duration</th>
              <th>Remarks</th>
              <th>Created At</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="quiz in quizzes" :key="quiz.id">
              <td>{{ quiz.date_of_quiz }}</td>
              <td>{{ quiz.time_duration }}</td>
              <td>{{ quiz.remarks }}</td>
              <td>{{ quiz.created_at }}</td>
              <td>
                <button @click="viewQuiz(quiz.id)" class="btn btn-primary">View</button>
                <button @click="editQuiz(quiz.id)" class="btn btn-warning">Edit</button>
                <button @click="deleteQuiz(quiz.id)" class="btn btn-danger">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <button @click="createQuiz" class="btn btn-primary mt-3">Create New Quiz</button>
    </div>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top">
      <div class="container-fluid">
        <a class="navbar-brand" href="/admin">Quiz Master</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
             <a class="nav-link" href="/admin/dashboard">Admin Dashboard</a>
            <a class="nav-link" href="/ad_logout">Logout</a>
            <a class="nav-link" href="/create_subject">Create Subject</a>
          </div>
        </div>
      </div>
    </nav>
  </div>

  `,
  data() {
    return {
      quizzes: [], // Array to store quizzes
      chapterId: null, // Chapter ID passed from the route
    };
  },

  mounted() {
    // Fetch the chapter ID from the route
    this.chapterId = this.$route.params.chapterId;
    // Fetch quizzes when the component is mounted
    this.fetchQuizzes();
  },

  methods: {
    // Fetch quizzes for the given chapter ID
    async fetchQuizzes() {
      try {
        const response = await fetch(`/api/admin/quizzes?chapter_id=${this.chapterId}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token for authentication
          },
        });
        if (!response.ok) {
          throw new Error("Failed to fetch quizzes");
        }
        const data = await response.json();
        this.quizzes = data.quizzes;
      } catch (error) {
        console.error("Error fetching quizzes:", error);
        alert("Failed to fetch quizzes. Please try again.");
      }
    },

    // Navigate to the view quiz page
    viewQuiz(quizId) {
      this.$router.push(`/view_quiz/${quizId}`);
    },

    // Navigate to the edit quiz page
    editQuiz(quizId) {
      this.$router.push(`/${this.chapterId}/edit_quiz/${quizId}`);
    },

    // Delete a quiz
    async deleteQuiz(quizId) {
      try {
        const response = await fetch(`/api/admin/quizzes/${quizId}`, {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token for authentication
          },
        });
        if (!response.ok) {
          throw new Error("Failed to delete quiz");
        }
        // Remove the deleted quiz from the list
        this.quizzes = this.quizzes.filter((quiz) => quiz.id !== quizId);
        alert("Quiz deleted successfully");
      } catch (error) {
        console.error("Error deleting quiz:", error);
        alert("Failed to delete quiz. Please try again.");
      }
    },

    // Navigate to the create quiz page
    createQuiz() {
      this.$router.push(`/${this.chapterId}/create_quiz`);
    },
  },
};

export default ViewChapter;
