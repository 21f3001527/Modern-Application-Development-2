const UserDashboard = {
    template: `
      <div>
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="/admin">Quiz Master</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#" @click.prevent="goToDashboard">Dashboard</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#" @click.prevent="goToSearch">Search Quizzes</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#" @click.prevent="goToSummary">Summary</a>
              </li>
            </ul>
            <button class="btn btn-outline-danger" @click="logout">Logout</button>
          </div>
        </div>
      </nav>

      <!-- Main Content -->
      <div class="container mt-5 pt-5">
        <!-- Welcome Banner -->
        <div class="row mb-4">
          <div class="col-12">
            <div class="alert alert-light border shadow-sm">
              <h4 class="mb-0"><i class="fas fa-user-circle text-primary me-2"></i>Welcome, {{ user.fullname }}!</h4>
            </div>
          </div>
        </div>

  
        <!-- Row: User Profile (Left) and Scores (Right) -->
        <div class="row g-4">
          <!-- User Profile -->
          <div class="col-md-4">
            <div class="card shadow-sm h-100">
              <div class="card-header bg-primary text-white">
                <div class="d-flex align-items-center">
                  <i class="fas fa-user-circle me-2"></i>
                  <h5 class="mb-0 fw-bold">Profile Details</h5>
                </div>
              </div>
              <div class="card-body">
                <ul class="list-group list-group-flush">
                  <li class="list-group-item px-0 d-flex">
                    <span class="text-muted me-2 w-50"><i class="fas fa-user me-2"></i>Full Name:</span>
                    <span class="fw-medium">{{ user.fullname }}</span>
                  </li>
                  <li class="list-group-item px-0 d-flex">
                    <span class="text-muted me-2 w-50"><i class="fas fa-calendar me-2"></i>Date of Birth:</span>
                    <span class="fw-medium">{{ user.dob }}</span>
                  </li>
                  <li class="list-group-item px-0 d-flex">
                    <span class="text-muted me-2 w-50"><i class="fas fa-graduation-cap me-2"></i>Qualification:</span>
                    <span class="fw-medium">{{ user.qualification }}</span>
                  </li>
                </ul>
              </div>
              <div class="card-footer bg-light">
                <a href="#" class="btn btn-sm btn-outline-primary" @click="editProfile">
                  <i class="fas fa-edit me-1"></i> Edit Profile
                </a>
              </div>
            </div>
          </div>
  
          <!-- Scores -->
          <div class="col-md-8">
            <div class="card shadow-sm h-100">
              <div class="card-header bg-success text-white">
                <div class="d-flex align-items-center justify-content-between">
                  <div>
                    <i class="fas fa-chart-line me-2"></i>
                    <h5 class="d-inline mb-0 fw-bold">Recent Performance</h5>
                  </div>
                  <span class="badge bg-light text-success">{{ scores.length }} Attempts</span>
                </div>
              </div>
              <div class="card-body">
                <div v-if="scores.length" class="table-responsive">
                  <table class="table table-hover align-middle mb-0">
                    <thead>
                      <tr class="table-light">
                        <th class="fw-semibold">Date</th>
                        <th class="fw-semibold text-center">Score</th>
                        <th class="fw-semibold text-end">Date & Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="score in scores" :key="score.id">
                        <td>{{ score.time_stamp_of_attempt.split(' ')[0] }}</td>
                        <td class="text-center">
                          <span :class="getScoreBadgeClass(score.percentage)">
                            {{ score.percentage }}%
                          </span>
                        </td>
                        <td class="text-end text-muted">
                          <small>{{ score.time_stamp_of_attempt }}</small>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div v-else class="text-center py-4">
                  <i class="fas fa-clipboard-list text-muted fa-3x mb-3"></i>
                  <p class="lead text-muted">No quiz attempts yet.</p>
                  <p class="small text-muted">Take your first quiz to see your performance here!</p>
                </div>
              </div>
            </div>
          </div>
        </div>
  
        <!-- Row: Quizzes (Full Width) -->
        <div class="row mt-4">
          <div class="col-12">
            <div class="card shadow-sm">
              <div class="card-header bg-info text-white">
                <div class="d-flex align-items-center justify-content-between">
                  <div>
                    <i class="fas fa-clipboard-list me-2"></i>
                    <h5 class="d-inline mb-0 fw-bold">Available Quizzes</h5>
                  </div>
                  <span class="badge bg-light text-info">{{ quizzes.length }} Quizzes</span>
                </div>
              </div>
              <div class="card-body">
                <div v-if="quizzes.length" class="table-responsive">
                  <table class="table table-hover align-middle">
                    <thead>
                      <tr class="table-light">
                        <th class="fw-semibold">Date</th>
                        <th class="fw-semibold">Duration</th>
                        <th class="fw-semibold">Subject</th>
                        <th class="fw-semibold">Chapter</th>
                        <th class="fw-semibold">Remarks</th>
                        <th class="fw-semibold text-center">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="quiz in quizzes" :key="quiz.id">
                        <td>{{ quiz.date_of_quiz }}</td>
                        <td>
                          <span class="badge bg-secondary">{{ quiz.time_duration }} mins</span>
                        </td>
                        <td>{{ quiz.subject_name }}</td>
                        <td>{{ quiz.chapter_name }}</td>
                        <td>
                          <small class="text-muted">{{ truncateRemarks(quiz.remarks) }}</small>
                        </td>
                        <td class="text-center">
                          <button type="button" class="btn btn-primary btn-sm" @click="attemptQuiz(quiz.id)">
                            <i class="fas fa-play-circle me-1"></i> Attempt
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div v-else class="text-center py-5">
                  <i class="fas fa-clipboard-list text-muted fa-4x mb-3"></i>
                  <p class="lead text-muted">No quizzes available at the moment.</p>
                  <p class="small text-muted">Check back later for new quizzes!</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
    data() {
      return {
        user: {},
        quizzes: [],
        scores: []
      };
    },
    methods: {
      async fetchDashboardData() {
        try {
          const response = await fetch('/api/user/dashboard', {
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
          });
          if (response.ok) {
            const data = await response.json();
            this.user = data.user;
            this.quizzes = data.quizzes;
            this.scores = data.scores;
          } else {
            console.error('Failed to fetch dashboard data');
          }
        } catch (error) {
          console.error('Error:', error);
        }
      },
      getScoreBadgeClass(percentage) {
        if (percentage >= 80) return 'badge bg-success';
        if (percentage >= 60) return 'badge bg-warning text-dark';
        return 'badge bg-danger';
      },
      truncateRemarks(remarks) {
        if (!remarks) return '';
        return remarks.length > 30 ? remarks.substring(0, 30) + '...' : remarks;
      },
      editProfile() {
        // Navigate to the profile edit page
        this.$router.push('/user/profile');
      },
      attemptQuiz(quizId) {
        console.log('Attempting quiz with ID:', quizId);
        // Navigate to the quiz attempt page with the quiz ID
        this.$router.push(`/user/attempt/${quizId}`);
      },
      goToDashboard() {
        // If already on dashboard, do nothing; otherwise, navigate to dashboard
        if (this.$route.path !== '/user/dashboard') {
          this.$router.push('/user/dashboard');
        }
      },
      goToSearch() {
        this.$router.push('/user/search');
      },
      goToSummary() {
        this.$router.push('/user/summary');
      },
      logout() {
        // Clear the token from localStorage
        localStorage.removeItem('token');
        // Redirect to login page
        this.$router.push('/');
      }
    },
    mounted() {
      this.fetchDashboardData();
    }
  };
  
  export default UserDashboard;
  