const EditChapter = {
  template: `
  <div>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="/admin">Quiz Master</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link" href="/ad_logout">Logout</a>
            <a class="nav-link" href="/create_chapter">Create Chapter</a>
            <a class="nav-link" href="/create_subject">Create Subject</a>
          </div>
        </div>
      </div>
    </nav>

    <!-- Edit Chapter Form -->
    <div class="container login-container">
      <div class="login-card">
        <h1>Edit Chapter</h1>
        <form @submit.prevent="updateChapter">
          <div class="form-group mb-3">
            <label for="chapter-name" class="form-label">Chapter Name</label>
            <input
              type="text"
              class="form-control"
              id="chapter-name"
              v-model="chapter.name"
              placeholder="Enter chapter name"
              required
            />
          </div>
          <div class="form-group mb-3">
            <label for="chapter-description" class="form-label">Description</label>
            <textarea
              class="form-control"
              id="chapter-description"
              v-model="chapter.description"
              placeholder="Enter chapter description"
            ></textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-custom">Update</button>
        </form>
      </div>
    </div>
  </div>
  `,

  data() {
    return {
      chapter: {
        id: null, // Chapter ID
        name: "", // Chapter name
        description: "", // Chapter description
        subject_id: null, // Subject ID
      },
    };
  },

  mounted() {
    // Fetch the chapter ID from the route
    const chapterId = this.$route.params.chapterId;
    this.chapter.id = chapterId;

    // Fetch the chapter details when the component is mounted
    this.fetchChapterDetails();
  },

  methods: {
    // Fetch chapter details from the backend
    async fetchChapterDetails() {
      try {
        const response = await fetch(`/api/admin/chapters/${this.chapter.id}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token for authentication
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch chapter details");
        }

        const data = await response.json();
        this.chapter.name = data.name;
        this.chapter.description = data.description;
        this.chapter.subject_id = data.subject_id;
      } catch (error) {
        console.error("Error fetching chapter details:", error);
        alert("Failed to fetch chapter details. Please try again.");
      }
    },

    // Update chapter details
    async updateChapter() {
      try {
        const response = await fetch(`/api/admin/chapters/${this.chapter.id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token for authentication
          },
          body: JSON.stringify({
            name: this.chapter.name,
            description: this.chapter.description,
            subject_id: this.chapter.subject_id,
          }),
        });

        if (!response.ok) {
          throw new Error("Failed to update chapter");
        }

        alert("Chapter updated successfully!");
        this.$router.push(`/view_subject/${this.chapter.subject_id}`); // Redirect to the subject page after update
      } catch (error) {
        console.error("Error updating chapter:", error);
        alert("Failed to update chapter. Please try again.");
      }
    },
  },
};


export default EditChapter;

