const CreateChapter = {
  template: `
  <div>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="/admin">Quiz Master</a>
        <a class="nav-link active" href="/admin/dashboard">Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link" href="/admin/dashboard">Admin Dashboard</a>
            <button class="nav-link btn btn-secondary" @click="goToAdminDashboard">Admin Dashboard</button>
            <a class="nav-link" href="/ad_logout">Logout</a>
            <a class="nav-link" href="/create_subject">Create Subject</a>
          </div>
        </div>
      </div>
    </nav>

    <div class="container login-container">
      <div class="login-card">
        <h1>Create Chapter</h1>
        <form @submit.prevent="createChapter">
          <div class="form-group mb-3">
            <label for="chapter-name" class="form-label">Chapter Name</label>
            <input
              type="text"
              class="form-control"
              id="chapter-name"
              v-model="chapter.name"
              placeholder="Enter chapter name"
              required
            />
          </div>
          <div class="form-group mb-3">
            <label for="chapter-description" class="form-label">Description</label>
            <textarea
              class="form-control"
              id="chapter-description"
              v-model="chapter.description"
              placeholder="Enter chapter description"
            ></textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-custom">Create</button>
        </form>
      </div>
    </div>
  </div>
  `,
  data() {
    return {
      chapter: {
        name: "",
        description: "",
        subject_id: null,
      },
    };
  },

  mounted() {
    this.chapter.subject_id = this.$route.params.subjectId;
  },

  methods: {
    async createChapter() {
      try {
        const response = await fetch("/api/admin/chapters", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
          body: JSON.stringify(this.chapter),
        });

        if (!response.ok) {
          throw new Error("Failed to create chapter");
        }

        const data = await response.json();
        alert("Chapter created successfully!");
        this.$router.push(`/view_subject/${this.chapter.subject_id}`);
      } catch (error) {
        console.error("Error creating chapter:", error);
        alert("Failed to create chapter. Please try again.");
      }
    },

    goToAdminDashboard() {
      this.$router.push('/admin/dashboard');
    },
  },
};

export default CreateChapter;

