const CreateSubject = {
  template: `
    <div class="container login-container">
      <div class="login-card">
        <h1>Create Subject</h1>
        <form @submit.prevent="createSubject">
          <div class="form-group mb-3">
            <label for="subject-name" class="form-label">Subject</label>
            <input 
              type="text" 
              class="form-control" 
              id="subject-name" 
              v-model="subject.name" 
              placeholder="Enter subject name" 
              required
            >
          </div>
          <div class="form-group mb-3">
            <label for="subject-description" class="form-label">Description</label>
            <textarea 
              class="form-control" 
              id="subject-description" 
              v-model="subject.description" 
              placeholder="Enter subject description"
            ></textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-custom">Create</button>
          <div v-if="message" class="alert" :class="isSuccess ? 'alert-success' : 'alert-danger'" role="alert">
            {{ message }}
          </div>
        </form>
      </div>
    </div>
  `,
  data() {
    return {
      subject: {
        name: '',
        description: ''
      },
      message: '',
      isSuccess: false
    }
  },
  methods: {
    async createSubject() {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          this.message = 'Authentication required';
          this.isSuccess = false;
          return;
        }
        
        const response = await fetch('/api/admin/subjects', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            name: this.subject.name,
            description: this.subject.description
          })
        });
        
        const data = await response.json();
        
        if (response.ok) {
          this.message = 'Subject created successfully';
          this.isSuccess = true;
          this.subject.name = '';
          this.subject.description = '';
          
          // Redirect to admin dashboard after successful creation
          setTimeout(() => {
            this.$router.push('/admin/dashboard');
          }, 2000);
        } else {
          this.message = data.message || 'Failed to create subject';
          this.isSuccess = false;
        }
      } catch (error) {
        console.error(error);
        this.message = 'An error occurred while creating the subject';
        this.isSuccess = false;
      }
    }
  }
};

export default CreateSubject;