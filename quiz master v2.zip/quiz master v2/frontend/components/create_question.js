const CreateQuestion = {
  template:`
  <div>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="/admin">Quiz Master</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link" href="/ad_logout">Logout</a>
            <a class="nav-link" href="/create_chapter">Create Chapter</a>
            <a class="nav-link" href="/create_subject">Create Subject</a>
          </div>
        </div>
      </div>
    </nav>

    <!-- Create Question Form -->
    <div class="container mt-4">
      <div class="card">
        <div class="card-header bg-primary text-white">
          <h3>Create Question</h3>
        </div>
        <div class="card-body">
          <form @submit.prevent="createQuestion">
            <div class="form-group mb-3">
              <label for="question_statement">Question Statement</label>
              <textarea
                class="form-control"
                id="question_statement"
                v-model="question.question_statement"
                placeholder="Enter the question"
                required
              ></textarea>
            </div>
            <div class="form-group mb-3">
              <label for="option1">Option 1</label>
              <input
                type="text"
                class="form-control"
                id="option1"
                v-model="question.option1"
                placeholder="Enter option 1"
                required
              />
            </div>
            <div class="form-group mb-3">
              <label for="option2">Option 2</label>
              <input
                type="text"
                class="form-control"
                id="option2"
                v-model="question.option2"
                placeholder="Enter option 2"
                required
              />
            </div>
            <div class="form-group mb-3">
              <label for="option3">Option 3</label>
              <input
                type="text"
                class="form-control"
                id="option3"
                v-model="question.option3"
                placeholder="Enter option 3"
                required
              />
            </div>
            <div class="form-group mb-3">
              <label for="option4">Option 4</label>
              <input
                type="text"
                class="form-control"
                id="option4"
                v-model="question.option4"
                placeholder="Enter option 4"
                required
              />
            </div>
            <div class="form-group mb-3">
              <label for="correct_option">Correct Option</label>
              <select
                class="form-control"
                id="correct_option"
                v-model="question.correct_option"
                required
              >
                <option value="1">Option 1</option>
                <option value="2">Option 2</option>
                <option value="3">Option 3</option>
                <option value="4">Option 4</option>
              </select>
            </div>
            <div class="form-group mb-3">
              <label for="marks">Marks</label>
              <input
                type="number"
                class="form-control"
                id="marks"
                v-model="question.marks"
                placeholder="Enter marks"
                required
              />
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  `,
  data() {
    return {
      question: {
        question_statement: "", // Question text
        option1: "", // Option 1
        option2: "", // Option 2
        option3: "", // Option 3
        option4: "", // Option 4
        correct_option: 1, // Correct option (default: Option 1)
        marks: 1.0, // Marks (default: 1.0)
        quiz_id: null, // Quiz ID passed from the route
      },
    };
  },

  mounted() {
    // Fetch the quiz ID from the route
    this.question.quiz_id = this.$route.params.quizId;
  },

  methods: {
    // Method to create a new question
    async createQuestion() {
      try {
        const response = await fetch("/api/admin/questions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token for authentication
          },
          body: JSON.stringify(this.question),
        });

        if (!response.ok) {
          throw new Error("Failed to create question");
        }

        const data = await response.json();
        alert("Question created successfully!");
        this.$router.push(`/view_quiz/${this.question.quiz_id}`); // Redirect to the quiz page after creation
      } catch (error) {
        console.error("Error creating question:", error);
        alert("Failed to create question. Please try again.");
      }
    },
  },
};

export default CreateQuestion;