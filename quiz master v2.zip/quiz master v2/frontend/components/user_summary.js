const UserSummary = {
    template: `
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container-fluid">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#" @click.prevent="goToDashboard">Dashboard</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#" @click.prevent="goToSearch">Search Quizzes</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#" @click.prevent="goToSummary">Summary</a>
              </li>
            </ul>
            <button class="btn btn-outline-danger" @click="logout">Logout</button>
          </div>
        </div>
      </nav>

      <div class="container mt-5">
        <div class="row">
          <div class="col-12 text-center my-4">
            <button @click="goToDashboard" class="btn btn-primary">
              <i class="fas fa-arrow-left"></i> Back to Dashboard
            </button>
          </div>
        </div>
  
        <h1 class="my-4">User Performance Summary</h1>
  
        <div v-if="loading" class="text-center my-5">
          <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
          <p class="mt-2">Loading your summary...</p>
        </div>
  
        <div v-else-if="error" class="alert alert-warning text-center">
          {{ error }}
        </div>
  
        <div v-else>
          <!-- Basic Stats Section -->
          <div class="row">
            <div class="col-md-6">
              <div class="card mb-4">
                <div class="card-body text-center">
                  <h3 class="card-title">Total Attempts</h3>
                  <p class="display-4">{{ totalAttempts }}</p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="card mb-4">
                <div class="card-body text-center">
                  <h3 class="card-title">Average Score</h3>
                  <p class="display-4">{{ avgScore }}%</p>
                </div>
              </div>
            </div>
          </div>
  
          <!-- Subject-wise Performance Table -->
          <h3 class="my-4">Subject-wise Performance</h3>
          <div class="table-responsive">
            <table class="table table-bordered">
              <thead class="table-light">
                <tr>
                  <th>Subject</th>
                  <th>Attempts</th>
                  <th>Average Score</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(data, subject) in subjectData" :key="subject">
                  <td>{{ subject }}</td>
                  <td>{{ data.attempts }}</td>
                  <td>
                    <span :class="getScoreBadgeClass(data.avg_score)">
                      {{ data.avg_score }}%
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
  
          <!-- Charts Section -->
          <div class="chart-container">
            <h3 class="my-4">Performance Charts</h3>
  
            <div class="row">
              <!-- Bar Chart for Average Scores by Subject -->
              <div class="col-md-6 mb-4">
                <div class="card">
                  <div class="card-header">
                    <h4 class="mb-0">Average Scores by Subject</h4>
                  </div>
                  <div class="card-body text-center">
                    <img v-if="scoreChart" :src="'data:image/png;base64,' + scoreChart" alt="Average Scores by Subject Chart" class="img-fluid">
                  </div>
                </div>
              </div>
  
              <!-- Pie Chart for Distribution of Attempts by Subject -->
              <div class="col-md-6 mb-4">
                <div class="card">
                  <div class="card-header">
                    <h4 class="mb-0">Distribution of Attempts by Subject</h4>
                  </div>
                  <div class="card-body text-center">
                    <img v-if="attemptChart" :src="'data:image/png;base64,' + attemptChart" alt="Distribution of Attempts Chart" class="img-fluid">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
    data() {
      return {
        loading: true,
        error: null,
        totalAttempts: 0,
        avgScore: 0,
        subjectData: {},
        scoreChart: '',
        attemptChart: ''
      };
    },
    methods: {
      async fetchSummaryData() {
        this.loading = true;
        try {          
          const response = await fetch('/api/user/summary', {            
            headers: {              
              'Authorization': `Bearer ${localStorage.getItem('token')}`            
            }
          });          
          if (response.ok) {            
            const data = await response.json();            
            this.totalAttempts = data?.total_attempts ?? 0;            
            this.avgScore = data?.avg_score ?? 0;            
            this.subjectData = data?.subject_data ?? {};            
            this.scoreChart = data?.score_chart ?? '';            
            this.attemptChart = data?.attempt_chart ?? '';            
            this.error = null;          
          } else {            
            const errorData = await response.json();            
            this.error = errorData?.message ?? 'Failed to load summary data';          
          }        
        } catch (err) {          
          if (err instanceof TypeError && err.message.includes('Failed to fetch')) {
            this.error = 'Network error: Could not connect to the server.';
          } else {
            this.error = 'An error occurred while fetching your summary';
            console.error('Error:', err);
          }
          
        } finally {
          this.loading = false;
        }
      },
      getScoreBadgeClass(score) {
        if (score >= 80) return 'badge bg-success';
        if (score >= 60) return 'badge bg-warning text-dark';
        return 'badge bg-danger';
      },
      
      goToDashboard() {
        this.$router.push('/user/dashboard');
      },
      // Add these missing methods
      goToSearch() {
        this.$router.push('/user/search');
      },
      goToSummary() {
        // If this is the current page, you might not need navigation
        // Or perhaps navigate to a different summary view
      },
      logout() {
        // Clear token from localStorage
        localStorage.removeItem('token');
        // Redirect to login page
        this.$router.push('/');
      }
      

    },
    mounted() {
      this.fetchSummaryData();
    }
  };
export default UserSummary;
  
