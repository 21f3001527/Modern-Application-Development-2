const ViewSubject = {
  template: `
    
  <div>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="/admin">Quiz Master</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link" href="/admin/dashboard">Admin Dashboard</a>
            <a class="nav-link" href="/logout">Logout</a>
            <a class="nav-link" href="/create_subject">Create Subject</a>
          </div>
        </div>
      </div>
    </nav>

    <!-- Main Content -->
    <div class="container">
      <h1>Chapters</h1>
      <div v-if="chapters.length === 0">
        <p>No chapters found.</p>
      </div>
      <div v-else>
        <table class="table table-striped">
          <thead>
            <tr>
              <th>Name</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="chapter in chapters" :key="chapter.id">
              <td>{{ chapter.name }}</td>
              <td>{{ chapter.description }}</td>
              <td>
                <button @click="viewChapter(chapter.id)" class="btn btn-primary">View</button>
                <button @click="editChapter(chapter.id)" class="btn btn-warning">Edit</button>
                <button @click="deleteChapter(chapter.id)" class="btn btn-danger">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <button @click="createChapter" class="btn btn-primary mt-3">Create New Chapter</button>
    </div>
  </div>
  `,
  data() {
    return {
      chapters: [], // Array to store chapters
      subjectId: null, // Subject ID passed from the route or props
    };
  },

  mounted() {
    // Fetch the subject ID from the route or props
    this.subjectId = this.$route.params.subjectId;
    // Fetch chapters when the component is mounted
    this.fetchSubjectData();
  },

  methods: {
    // Fetch chapters for the given subject ID
    async fetchSubjectData() {
      try {
        const response = await fetch(`/api/admin/chapters?subject_id=${this.subjectId}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`, // Include JWT token for authentication
          },
        });
        if (!response.ok) {
          throw new Error('Failed to fetch chapters');
        }
        const data = await response.json();
        this.chapters = data.chapters;
      } catch (error) {
        console.error('Error fetching chapters:', error);
      }
    },

    // Navigate to the view chapter page
    viewChapter(chapterId) {
      this.$router.push(`/view_chapter/${chapterId}`);
    },

    // Navigate to the edit chapter page
    editChapter(chapterId) {
      this.$router.push(`/${this.subjectId}/edit_chapter/${chapterId}`);
    },

    // Delete a chapter
    async deleteChapter(chapterId) {
      try {
        const response = await fetch(`/api/admin/chapters/${chapterId}`, {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`, // Include JWT token for authentication
          },
        });
        if (!response.ok) {
          throw new Error('Failed to delete chapter');
        }
        // Remove the deleted chapter from the list
        this.chapters = this.chapters.filter((chapter) => chapter.id !== chapterId);
        alert('Chapter deleted successfully');
      } catch (error) {
        console.error('Error deleting chapter:', error);
        alert('Failed to delete chapter');
      }
    },

    // Navigate to the create chapter page
    createChapter() {
      this.$router.push(`/${this.subjectId}/create_chapter`);
    },
  },
};


export default ViewSubject;