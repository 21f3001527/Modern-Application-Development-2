const CreateQuiz = {
  template: `
  <div>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="/admin">Quiz Master</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link" href="/ad_logout">Logout</a>
            <a class="nav-link" href="/create_subject">Create Subject</a>
          </div>
        </div>
      </div>
    </nav>

    <!-- Create Quiz Form -->
    <div class="container login-container">
      <div class="login-card">
        <h1>Create Quiz</h1>
        <form @submit.prevent="createQuiz">
          <div class="form-group mb-3">
            <label for="date_of_quiz" class="form-label">Date of Quiz</label>
            <input
              type="date"
              class="form-control"
              id="date_of_quiz"
              v-model="quiz.date_of_quiz"
              placeholder="Enter date of quiz"
              required
            />
          </div>
          <div class="form-group mb-3">
           <label for="time_duration" class="form-label">Time Duration (in minutes)</label>
            <input
              type="number"
              class="form-control"
              id="time_duration"
              v-model="quiz.time_duration"
              placeholder="Enter time duration in minutes"
              required
            />
          </div>
          <div class="form-group mb-3">
            <label for="remarks" class="form-label">Remarks</label>
            <input
              type="text"
              class="form-control"
              id="remarks"
              v-model="quiz.remarks"
              placeholder="Enter remarks"
            />
          </div>
          <button type="submit" class="btn btn-primary btn-custom">Create</button>
        </form>
      </div>
    </div>
  </div>
  `,
  data() {
    return {
      quiz: {
        date_of_quiz: "", // Date of the quiz
        time_duration: null, // Time duration of the quiz
        remarks: "", // Remarks for the quiz
        chapter_id: null, // Chapter ID passed from the route
      },
    };
  },

  mounted() {
    // Fetch the chapter ID from the route
    this.quiz.chapter_id = this.$route.params.chapterId;

  },

  methods: {
    // Method to create a new quiz
    async createQuiz() {
      try {
        const response = await fetch("/api/admin/quizzes", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token for authentication
          },
          body: JSON.stringify(this.quiz),
        });

        if (!response.ok) {
          throw new Error("Failed to create quiz");
        }

        const data = await response.json();
        alert("Quiz created successfully!");
        this.$router.push(`/view_chapter/${this.quiz.chapter_id}`); // Redirect to the chapter page after creation
        

      } catch (error) {
        console.error("Error creating quiz:", error);
        alert("Failed to create quiz. Please try again.");
      }
    },
  },
};

export default CreateQuiz;