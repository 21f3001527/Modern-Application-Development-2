const QuizAttempt = {
    template: `
     <div class="container mt-5">
      <div class="card">
        <div class="card-header">
          <h2 class="text-center">Quiz</h2>
          <div class="d-flex justify-content-between align-items-center">
            <p class="text-muted mb-0">
              Duration: {{ quiz.time_duration }} mins | 
              Date: {{ quiz.date_of_quiz }}
            </p>
            <div class="timer-display" :class="{'text-danger': timeLeft < 60}">
              <i class="fas fa-clock me-1"></i> Time Left: {{ formatTime(timeLeft) }}
            </div>
          </div>
        </div>
          <div class="card-body">
            <form @submit.prevent="submitQuiz">
              <div v-for="(question, index) in questions" :key="question.id" class="question-container mb-4">
                <h5 class="question-text">
                  {{ index + 1 }}. {{ question.question_statement }}
                </h5>
                <div class="options-container ms-4">
                  <div class="form-check">
                    <input class="form-check-input" type="radio" 
                           :name="'question_' + question.id" 
                           :id="'q' + question.id + '_option1'" 
                           :value="1"
                           v-model="answers[question.id]" required>
                    <label class="form-check-label" :for="'q' + question.id + '_option1'">
                      1. {{ question.option1 }}
                    </label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" 
                           :name="'question_' + question.id" 
                           :id="'q' + question.id + '_option2'" 
                           :value="2"
                           v-model="answers[question.id]">
                    <label class="form-check-label" :for="'q' + question.id + '_option2'">
                      2. {{ question.option2 }}
                    </label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" 
                           :name="'question_' + question.id" 
                           :id="'q' + question.id + '_option3'" 
                           :value="3"
                           v-model="answers[question.id]">
                    <label class="form-check-label" :for="'q' + question.id + '_option3'">
                      3. {{ question.option3 }}
                    </label>
                  </div>
                  <div class="form-check">
                    <input class="form-check-input" type="radio" 
                           :name="'question_' + question.id" 
                           :id="'q' + question.id + '_option4'" 
                           :value="4"
                           v-model="answers[question.id]">
                    <label class="form-check-label" :for="'q' + question.id + '_option4'">
                      4. {{ question.option4 }}
                    </label>
                  </div>
                </div>
              </div>
              
              <div class="d-grid gap-2 col-6 mx-auto mt-4">
                <button type="submit" class="btn btn-primary">Submit Quiz</button>
                <button type="button" @click="cancelQuiz" class="btn btn-secondary">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      
      <style>
        .timer-display {
          font-size: 1.2rem;
          font-weight: bold;
          padding: 0.5rem 1rem;
          background-color: #f8f9fa;
          border-radius: 0.5rem;
        }
        .question-container {
          border-bottom: 1px solid #eee;
          padding-bottom: 1rem;
        }
        .question-container:last-child {
          border-bottom: none;
        }
        .question-text {
          color: #2c3e50;
          margin-bottom: 1rem;
        }
        .options-container {
          background-color: #f8f9fa;
          padding: 1rem;
          border-radius: 0.5rem;
        }
        .form-check {
          margin-bottom: 0.5rem;
        }
        .form-check:last-child {
          margin-bottom: 0;
        }
      </style>
    `,
    data() {
        return {
          quiz: {},
          questions: [],
          answers: {},
          timeLeft: 0,
          timer: null,
        }
      },
      methods: {
        async fetchQuiz() {
          try {
            const response = await fetch(`/api/user/attempt/${this.$route.params.quizId}`, {
              headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
              }
            });
            if (response.ok) {
              const data = await response.json();
              this.quiz = data.quiz;
              this.questions = data.questions;
              
              // Initialize timer if time_duration is available
              if (this.quiz.time_duration) {
                this.timeLeft = this.quiz.time_duration * 60;
                this.startTimer();
              }
            } else {
              console.error('Failed to fetch quiz');
            }
          } catch (error) {
            console.error('Error:', error);
          }
        },
        
      formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
      },
        
      startTimer() {
        this.timer = setInterval(() => {
          this.timeLeft--;
          if (this.timeLeft <= 0) {
            clearInterval(this.timer);
            alert('Time is up! Submitting quiz...');
            this.submitQuiz();
          }
        }, 1000);
      },
      async submitQuiz() {
        // Check if all questions are answered
        if (Object.keys(this.answers).length < this.questions.length) {
          if (!confirm('You have not answered all questions. Do you still want to submit?')) {
            return;
          }
        }
        
        try {
          const response = await fetch(`/api/user/attempt/${this.quiz.id}`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({ answers: this.answers })
          });
          
          if (response.ok) {
            const result = await response.json();
            alert(`Quiz completed! Your score: ${result.score.percentage.toFixed(1)}%`);
            this.$router.push('/user/dashboard');
          } else {
            console.error('Failed to submit quiz');
          }
        } catch (error) {
          console.error('Error:', error);
        }
      },
      cancelQuiz() {
        if (confirm('Are you sure you want to cancel this quiz? Your progress will be lost.')) {
          clearInterval(this.timer);
          this.$router.push('/user/dashboard');
        }
      }
    },
    mounted() {
      this.fetchQuiz();
    },
    beforeUnmount() {
      if (this.timer) {
        clearInterval(this.timer);
      }
    }
  };
  
  export default QuizAttempt;
