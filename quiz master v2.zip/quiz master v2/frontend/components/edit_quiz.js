const EditQuiz = {
 
  template: `

  <div>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="/admin">Quiz Master</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-link" href="/ad_logout">Logout</a>
            <a class="nav-link" href="/create_chapter">Create Chapter</a>
            <a class="nav-link" href="/create_subject">Create Subject</a>
          </div>
        </div>
      </div>
    </nav>

    <!-- Edit Quiz Form -->
    <div class="container mt-5">
      <div class="text-center">
        <h1>Edit Quiz</h1>
      </div>
      <div class="row d-flex justify-content-center align-items-center">
        <div class="col-md-8 col-lg-6 col-xl-4">
          <form @submit.prevent="updateQuiz">
            <div class="form-group">
              <label for="date_of_quiz">Date of Quiz</label>
              <input
                type="date"
                class="form-control"
                id="date_of_quiz"
                v-model="quiz.date_of_quiz"
                placeholder="Enter date of quiz"
                required
              />
            </div>
            <div class="form-group">
              <label for="time_duration">Time Duration (minutes)</label>
              <input
                type="number"
                class="form-control"
                id="time_duration"
                v-model="quiz.time_duration"
                placeholder="Enter time duration"
                required
              />
            </div>
            <div class="form-group">
              <label for="remarks">Remarks</label>
              <input
                type="text"
                class="form-control"
                id="remarks"
                v-model="quiz.remarks"
                placeholder="Enter remarks"
              />
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  `,

  data() {

    return {
      quiz: {
        id: null, // Quiz ID
        date_of_quiz: "", // Date of the quiz
        time_duration: null, // Time duration of the quiz in minutes
        remarks: "", // Remarks for the quiz
        chapter_id: null, // Chapter ID
      },
    };
  },

  mounted() {
    // Fetch the quiz ID from the route
    const quizId = this.$route.params.quizId;
    this.quiz.id = quizId;

    // Fetch the quiz details when the component is mounted
    this.fetchQuizDetails();
  },

  methods: {
    // Fetch quiz details from the backend
    async fetchQuizDetails() {
      try {
        const response = await fetch(`/api/admin/quizzes/${this.quiz.id}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token for authentication
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch quiz details");
        }

        const data = await response.json();
        this.quiz.date_of_quiz = data.date_of_quiz;
        this.quiz.time_duration = data.time_duration;
        this.quiz.remarks = data.remarks;
        this.quiz.chapter_id = data.chapter_id;
      } catch (error) {
        console.error("Error fetching quiz details:", error);
        alert("Failed to fetch quiz details. Please try again.");
      }
    },

    // Update quiz details
    async updateQuiz() {
      try {
        const response = await fetch(`/api/admin/quizzes/${this.quiz.id}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token for authentication
          },
          body: JSON.stringify({
            date_of_quiz: this.quiz.date_of_quiz,
            time_duration: this.quiz.time_duration,
            remarks: this.quiz.remarks,
            chapter_id: this.quiz.chapter_id,
          }),
        });

        if (!response.ok) {
          throw new Error("Failed to update quiz");
        }

        alert("Quiz updated successfully!");
        this.$router.push(`/view_chapter/${this.quiz.chapter_id}`); // Redirect to the chapter page after update
      } catch (error) {
        console.error("Error updating quiz:", error);
        alert("Failed to update quiz. Please try again.");
      }
    },
  },
};


export default EditQuiz;

