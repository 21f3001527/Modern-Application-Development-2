const UserLogin = {
  template: `
      <div class="container mt-5">
          <h2>User Login</h2>
          <form @submit.prevent="login">
              <div class="mb-3">
                  <label class="form-label">Email</label>
                  <input type="email" v-model="email" class="form-control" required>
              </div>
              <div class="mb-3">
                  <label class="form-label">Password</label>
                  <input type="password" v-model="password" class="form-control" required>
              </div>
              <button type="submit" class="btn btn-primary">Login</button>
          </form>
          <p class="mt-3">Don't have an account? <router-link to="/register">Register</router-link></p>
      </div>
  `,
  data() {
      return { email: '', password: '' };
  },
  methods: {
      async login() {
          try {
              const response = await fetch('/api/user/login', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ email: this.email, password: this.password }),
                  credentials: 'include'
              });
              const data = await response.json();
              if (response.ok) {
                  alert(data.message);
                  localStorage.setItem('token', data.access_token);
                  this.$router.push('/user/dashboard');
              } else {
                  alert(data.message || 'Login failed');
              }
          } catch (error) {
              console.error('Error logging in:', error);
              alert('An error occurred during login');
          }
      }
  }
};
export default UserLogin;