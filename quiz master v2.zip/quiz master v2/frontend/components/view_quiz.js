const ViewQuiz = {
  template: `
    <div>
      <!-- Navigation Bar -->
      <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="/admin/dashboard">admin dashboard</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
              <a class="navbar-brand" href="/admin">Quiz Master</a>
              <a class="nav-link" href="/ad_logout">Logout</a>
              <a class="nav-link" href="/create_subject">Create Subject</a>
            </div>
          </div>
        </div>
      </nav>

      <!-- Quiz Details -->
      <div class="container mt-4">
        <div class="card">
          <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h3>Quiz Details</h3>
            <router-link :to="\`/create_question/\${quiz.id}\`" class="btn btn-success">Add New Question</router-link>
          </div>
          <div class="card-body">
            <div v-if="quiz.id" class="quiz-info mb-4">
              <h4>Quiz Information</h4>
              <table class="table table-bordered">
                <tr>
                  <th width="30%">Date of Quiz</th>
                  <td>{{ quiz.date_of_quiz }}</td>
                </tr>
                <tr>
                  <th>Duration</th>
                  <td>{{ quiz.time_duration }} minutes</td>
                </tr>
                <tr>
                  <th>Remarks</th>
                  <td>{{ quiz.remarks || 'No remarks' }}</td>
                </tr>
              </table>
            </div>

            <!-- Questions Section -->
            <div class="questions-section">
              <h4>Questions ({{ questions.length }})</h4>
              <div v-if="questions.length === 0" class="alert alert-info">No questions added yet.</div>
              <div v-else>
                <div v-for="(question, index) in questions" :key="question.id" class="card mb-3">
                  <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Question {{ index + 1 }}</h5>
                    <div>
                      <router-link :to="\`/edit_question/\${question.id}\`" class="btn btn-warning btn-sm">Edit</router-link>
                      <button @click="deleteQuestion(question.id)" class="btn btn-danger btn-sm">Delete</button>
                    </div>
                  </div>
                  <div class="card-body">
                    <p class="card-text"><strong>Question:</strong> {{ question.question_statement }}</p>
                    <div class="options">
                      <p :class="{ 'text-success font-weight-bold': question.correct_option === 1 }">
                        1. {{ question.option1 }}
                      </p>
                      <p :class="{ 'text-success font-weight-bold': question.correct_option === 2 }">
                        2. {{ question.option2 }}
                      </p>
                      <p :class="{ 'text-success font-weight-bold': question.correct_option === 3 }">
                        3. {{ question.option3 }}
                      </p>
                      <p :class="{ 'text-success font-weight-bold': question.correct_option === 4 }">
                        4. {{ question.option4 }}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <router-link :to="\`/view_chapter/\${quiz.chapter_id}\`" class="btn btn-secondary">Back to Chapter</router-link>
          </div>
        </div>
      </div>
    </div>
  `,

  data() {
    return {
      quiz: {
        id: null,
        date_of_quiz: "",
        time_duration: null,
        remarks: "",
        chapter_id: null,
      },
      questions: [], // Array to store questions
    };
  },

  mounted() {
    // Fetch the quiz ID from the route
    const quizId = this.$route.params.quizId;
    this.quiz.id = quizId;

    // Fetch quiz and questions when the component is mounted
    this.fetchQuizDetails();
    this.fetchQuestions();
  },

  methods: {
    // Fetch quiz details from the backend
    async fetchQuizDetails() {
      try {
        const response = await fetch(`/api/admin/quizzes/${this.quiz.id}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token for authentication
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch quiz details");
        }

        const data = await response.json();
        this.quiz.date_of_quiz = data.date_of_quiz;
        this.quiz.time_duration = data.time_duration;
        this.quiz.remarks = data.remarks;
        this.quiz.chapter_id = data.chapter_id;
      } catch (error) {
        console.error("Error fetching quiz details:", error);
        alert("Failed to fetch quiz details. Please try again.");
      }
    },

    // Fetch questions for the quiz
    async fetchQuestions() {
      try {
        const response = await fetch(`/api/admin/questions?quiz_id=${this.quiz.id}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token for authentication
          },
        });

        if (!response.ok) {
          throw new Error("Failed to fetch questions");
        }

        const data = await response.json();
        this.questions = data.questions;
      } catch (error) {
        console.error("Error fetching questions:", error);
        alert("Failed to fetch questions. Please try again.");
      }
    },

    // Delete a question
    async deleteQuestion(questionId) {
      if (!confirm("Are you sure you want to delete this question?")) {
        return;
      }

      try {
        const response = await fetch(`/api/admin/questions/${questionId}`, {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Include JWT token for authentication
          },
        });

        if (!response.ok) {
          throw new Error("Failed to delete question");
        }

        // Remove the deleted question from the list
        this.questions = this.questions.filter((q) => q.id !== questionId);
        alert("Question deleted successfully");
      } catch (error) {
        console.error("Error deleting question:", error);
        alert("Failed to delete question. Please try again.");
      }
    },
  },
};

export default ViewQuiz;