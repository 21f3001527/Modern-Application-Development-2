const AdminSummary = {
    template: `
      <nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top">
      <div class="container-fluid">
        <a class="navbar-brand" href="/admin">Quiz Master</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav me-auto">
            <a class="nav-link active" href="/admin/dashboard">Dashboard</a>
            <a class="nav-link" href="/admin/summary">Summary</a>
            <a class="nav-link" href="/search">Search</a>
            <a class="nav-link" href="/create_subject">Create Subject</a>
          </div>
          <div class="navbar-nav">
            <button class="nav-link btn btn-danger text-white ms-2" @click="logout">Logout</button>
          </div>
        </div>
      </div>
    </nav>
      <div class="container mt-5">
        <h2 class="text-center mb-4">Admin Dashboard Summary</h2>
        
        <!-- Statistics Cards -->
        <div class="row mb-4">
          <div class="col-md-3">
            <div class="card bg-primary text-white">
              <div class="card-body text-center">
                <h5 class="card-title">Total Users</h5>
                <h2 class="display-4">{{ statistics.total_users }}</h2>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card bg-success text-white">
              <div class="card-body text-center">
                <h5 class="card-title">Total Subjects</h5>
                <h2 class="display-4">{{ statistics.total_subjects }}</h2>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card bg-info text-white">
              <div class="card-body text-center">
                <h5 class="card-title">Total Quizzes</h5>
                <h2 class="display-4">{{ statistics.total_quizzes }}</h2>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card bg-warning text-white">
              <div class="card-body text-center">
                <h5 class="card-title">Total Attempts</h5>
                <h2 class="display-4">{{ statistics.total_scores }}</h2>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Chart Section -->
        <div class="row mb-4">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h5 class="card-title">Quizzes per Subject</h5>
              </div>
              <div class="card-body text-center">
                <img v-if="plotUrl" :src="'data:image/png;base64,' + plotUrl" class="img-fluid" alt="Quizzes per Subject Chart">
                <div v-else class="alert alert-warning">No chart data available</div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Recent Scores Section -->
        <div class="row mb-4">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h5 class="card-title">Recent Quiz Attempts</h5>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>User</th>
                        <th>Quiz</th>
                        <th>Score</th>
                        <th>Date & Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="score in recentScores" :key="score.id">
                        <td>{{ score.user_name }}</td>
                        <td>{{ score.quiz_name }}</td>
                        <td>
                          <span :class="getScoreBadgeClass(score.percentage)">
                            {{ score.percentage }}%
                          </span>
                        </td>
                        <td>{{ score.time_stamp }}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Subject Details Section -->
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h5 class="card-title">Subject Details</h5>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Subject</th>
                        <th>Chapters</th>
                        <th>Quizzes</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="subject in subjectDetails" :key="subject.id">
                        <td>{{ subject.name }}</td>
                        <td>{{ subject.chapter_count }}</td>
                        <td>{{ subject.quiz_count }}</td>
                        <td>
                          <a :href="'/view_subject/' + subject.id" class="btn btn-sm btn-primary">View</a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
    data() {
      return {
        statistics: {
          total_users: 0,
          total_subjects: 0,
          total_quizzes: 0,
          total_scores: 0
        },
        plotUrl: '',
        recentScores: [],
        subjectDetails: []
      };
    },
    methods: {
      async fetchSummaryData() {
        try {
          const response = await fetch('/api/admin/summary', {
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
          });
          
          if (response.ok) {
            const data = await response.json();
            this.statistics = data.statistics;
            this.plotUrl = data.plot_url;
            this.recentScores = data.recent_scores;
            this.subjectDetails = data.subject_details;
          } else {
            console.error('Failed to fetch summary data');
          }
        } catch (error) {
          console.error('Error:', error);
        }
      },
      getScoreBadgeClass(percentage) {
        if (percentage >= 80) return 'badge bg-success';
        if (percentage >= 60) return 'badge bg-warning text-dark';
        return 'badge bg-danger';
      },
      logout() {
        // Clear the token from localStorage
        localStorage.removeItem('token');
        this.$router.push('/');
      }
    },
    mounted() {
      this.fetchSummaryData();
    }
  };
  
  export default AdminSummary;
  