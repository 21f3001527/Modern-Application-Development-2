const EditSubject = {
  template: `
  <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
      <router-link class="navbar-brand" to="/admin">Quiz Master</router-link>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
          <router-link class="nav-link" to="/logout">Logout</router-link>
          <router-link class="nav-link" to="/create_subject">Create Subject</router-link>
        </div>
      </div>
    </div>
  </nav>
  <div class="container mt-5">
    <div class="text-center">
      <h1>Edit Subject</h1>
    </div>
    <div class="row d-flex justify-content-center align-items-center">
      <div class="col-md-8 col-lg-6 col-xl-4">
        <form @submit.prevent="editSubject">
          <div class="form-group">
            <label for="name">Subject Name</label>
            <input type="text" class="form-control" id="name" v-model="subject.name" placeholder="Enter subject name">
          </div>
          <div class="form-group">
            <label for="description">Description</label>
            <input type="text" class="form-control" id="description" v-model="subject.description" placeholder="Enter description">
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>
    </div>
  </div>
  `,
  data() {
    return {
      subject: {
        name: '',
        description: ''
      }
    }
  },
  methods: {
    async fetchSubject() {
      try {
        const response = await fetch(`/api/admin/subjects/${this.$route.params.id}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        if (!response.ok) {
          const data = await response.json();
          throw new Error(data.message);
        }
        const data = await response.json();
        this.subject = data;
      } catch (error) {
        console.error('Error fetching subject:', error.message);
      }
    },
    async editSubject() {
      try {
        const response = await fetch(`/api/admin/subjects/${this.$route.params.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          },
          body: JSON.stringify({
            name: this.subject.name,
            description: this.subject.description
          })
        });
        if (!response.ok) {
          const data = await response.json();
          throw new Error(data.message);
        }
        alert('Subject updated successfully')
        this.$router.push('/admin/dashboard');
      } catch (error) {
        console.error('Error updating subject:', error.message);
      }
    }
  },
  created() {
    this.fetchSubject();
  }
};

export default EditSubject;

