const AdminDashboard = {
  template: `
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top">
      <div class="container-fluid">
        <a class="navbar-brand" href="/admin">Quiz Master</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav me-auto">
            <a class="nav-link active" href="/admin/dashboard">Dashboard</a>
            <a class="nav-link" href="/admin/summary">Summary</a>
            <a class="nav-link" href="/search">Search</a>
            <a class="nav-link" href="/create_subject">Create Subject</a>
            <button class="nav-link btn btn-secondary" @click="exportCSV">Export CSV</button>
            
          </div>
          <div class="navbar-nav">
            <button class="nav-link btn btn-danger text-white ms-2" @click="logout">Logout</button>
          </div>
        </div>
      </div>
    </nav>
    <div class="container-fluid mt-5 pt-4">
      <div class="row mb-4">
        <div class="col-12 text-center">
          <h1 class="display-5">Welcome to Admin Dashboard</h1>
          <p class="lead">Manage your subjects, chapters, and quizzes effectively</p>
        </div>
      </div>
      <div class="card mb-4">
        <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
          <h5 class="mb-0">Manage Subjects</h5>
          <router-link :to="'/create_subject'" class="btn btn-success btn-sm">
            <i class="fas fa-plus"></i> Add New Subject
          </router-link>
        </div>
        <div class="card-body">
          <div v-if="!subjects || subjects.length === 0" class="alert alert-info">
            No subjects found. Create your first subject to get started!
          </div>
          <div v-else class="table-responsive">
            <table class="table table-hover table-striped">
              <thead class="table-dark">
                <tr>
                  <th>Subject Name</th>
                  <th>Description</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="subject in subjects" :key="subject.id">
                  <td>{{ subject.name }}</td>
                  <td>{{ subject.description }}</td>
                  
                
                  <td>
                    <div class="btn-group">
                      <router-link :to="'/view_subject/' + subject.id" class="btn btn-primary btn-sm">
                        <i class="fas fa-eye"></i> View
                      </router-link>
                      <router-link :to="'/edit_subject/' + subject.id" class="btn btn-warning btn-sm">
                        <i class="fas fa-edit"></i> Edit
                      </router-link>
                      <button type="button" class="btn btn-danger btn-sm" @click="confirmDeleteSubject(subject)">
                        <i class="fas fa-trash"></i> Delete
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `,
  data() {
    return {
      subjects: [],
    }
  },
  methods: {
    async fetchData() {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          console.error('Token not found');
          this.$router.push('/');
  
        }
        const response = await fetch('/api/admin/subjects', {
          method: "GET",
          headers: {
            'Content-type': "application/json",
            'Authorization': `Bearer ${token}`,
          },
        });
        if (response.ok) {
          const data = await response.json();
          this.subjects = data.subjects;
        }
      } catch (error) {
        console.error(error);
      }
    },
    logout() {
      // Clear the token from localStorage
      localStorage.removeItem('token');
      // Redirect to login page
      this.$router.push('/');
    },    
    async deleteSubject(subject) {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          console.error('Token not found');
          return;
        }
        const response = await fetch(`/api/admin/subjects/${subject.id}`, {
          method: "DELETE",
          headers: {
            'Content-type': "application/json",
            'Authorization': `Bearer ${token}`,
          },
        });
        if (response.ok) {
          this.subjects = this.subjects.filter(s => s.id !== subject.id);
          alert("Subject deleted successfully");
        } else {
          const data = await response.json();
          alert(data.message);
        }
      } catch (error) {
        console.error(error);
      }
    },
    confirmDeleteSubject(subject) {
      if (confirm(`Are you sure you want to delete the subject "${subject.name}"?`)) {
        this.deleteSubject(subject);
      }
    },
    async exportCSV() {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          console.error('Token not found');
          return;
        }
        const response = await fetch('/api/admin/export-csv', {
          method: "GET",
          headers: {
            'Content-type': "application/json",
            'Authorization': `Bearer ${token}`,
          },
        });
        if (response.ok) {
          const data = await response.json();
          alert(data.message);
        } else {
          const errorData = await response.json();
          alert(errorData.message);
        }
      } catch (error) {
        console.error(error);
      }
    }


  },
  mounted() {
    this.fetchData();
  }
};

export default AdminDashboard;

